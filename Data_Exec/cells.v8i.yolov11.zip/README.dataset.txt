# cells > 2024-07-02 9:31pm
https://universe.roboflow.com/terter/cells-ido8e

Provided by a Roboflow user
License: CC BY 4.0

