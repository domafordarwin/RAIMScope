# -*- coding: utf-8 -*-

import datetime
import json
import math
import os
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

from PyQt4.QtCore import (
    Qt,
    QTimer,
    QRect,
    QPoint,
    pyqtSignal
)
from PyQt4.QtGui import (
    QApplication,
    QWidget,
    QLabel,
    QPushButton,
    QComboBox,
    QSlider,
    QSpinBox,
    QDoubleSpinBox,
    QCheckBox,
    QProgressBar,
    QHBoxLayout,
    QVBoxLayout,
    QGridLayout,
    QGroupBox,
    QTabWidget,
    QTextBrowser,
    QLineEdit,
    QFileDialog,
    QMessageBox,
    QInputDialog,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QImage,
    QPixmap,
    QPainter,
    QPen,
    QColor
)

from led_controller import LEDController
from dpc_engine import (
    correct_frame,
    crop_roi,
    dpc_color,
    dpc_quality,
    exposure_metrics,
    focus_score,
    illumination_na_estimate,
    integrate_gradients_fft,
    opd_from_phase_like,
    positive_to_u8,
    register_frames,
    signed_to_u8,
    compute_dpc_4,
    compute_dpc_8,
    to_gray
)
from analysis_engine import (
    classical_segment,
    ONNXSegmenter
)
from help_topics import HELP_TOPICS


class ROIImageLabel(QLabel):
    roiChanged = pyqtSignal(object)

    def __init__(self, parent=None):
        super(ROIImageLabel, self).__init__(parent)
        self.setFixedSize(640, 480)
        self.setAlignment(Qt.AlignCenter)
        self._dragging = False
        self._start = QPoint()
        self._end = QPoint()
        self._roi = None

    def roi(self):
        return self._roi

    def clear_roi(self):
        self._roi = None
        self._dragging = False
        self.update()
        self.roiChanged.emit(None)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._start = event.pos()
            self._end = event.pos()
            self.update()

    def mouseMoveEvent(self, event):
        if self._dragging:
            self._end = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        if self._dragging and event.button() == Qt.LeftButton:
            self._dragging = False
            self._end = event.pos()

            x1 = max(0, min(self._start.x(), self._end.x()))
            y1 = max(0, min(self._start.y(), self._end.y()))
            x2 = min(self.width(), max(self._start.x(), self._end.x()))
            y2 = min(self.height(), max(self._start.y(), self._end.y()))

            if x2 - x1 >= 8 and y2 - y1 >= 8:
                self._roi = (
                    int(x1),
                    int(y1),
                    int(x2 - x1),
                    int(y2 - y1)
                )
            else:
                self._roi = None

            self.update()
            self.roiChanged.emit(self._roi)

    def paintEvent(self, event):
        super(ROIImageLabel, self).paintEvent(event)

        rectangle = None
        if self._dragging:
            rectangle = QRect(self._start, self._end).normalized()
        elif self._roi is not None:
            rectangle = QRect(
                self._roi[0],
                self._roi[1],
                self._roi[2],
                self._roi[3]
            )

        if rectangle is not None:
            painter = QPainter(self)
            painter.setPen(QPen(QColor(255, 255, 0), 2, Qt.DashLine))
            painter.drawRect(rectangle)


class AdvancedDPCGUI(QWidget):

    FOUR_DIRECTIONS = [
        "left",
        "right",
        "top",
        "bottom"
    ]

    EIGHT_DIRECTIONS = [
        "right",
        "bottom_right",
        "bottom",
        "bottom_left",
        "left",
        "top_left",
        "top",
        "top_right"
    ]

    def __init__(self):
        super(AdvancedDPCGUI, self).__init__()

        self.base_dir = Path(__file__).resolve().parent
        self.output_dir = self.base_dir / "output"
        self.calibration_dir = self.base_dir / "calibration"
        self.output_dir.mkdir(exist_ok=True)
        self.calibration_dir.mkdir(exist_ok=True)

        self.led = LEDController()
        self.cap = None

        self.current_frame = None
        self.current_display = None
        self.current_display_name = "Live"
        self.zoom = 1.0
        self.frame_counter = 0

        self.dark_frame = None
        self.flat_frames = {}
        self.calibration_metadata = {}

        self.result_images = {}
        self.result_float = {}
        self.last_raw_frames = {}
        self.last_registration = {}
        self.last_quality = {}

        self.busy = False
        self.sequence = []
        self.sequence_index = 0
        self.sequence_frames = {}
        self.sequence_callback = None
        self.sequence_purpose = ""
        self.sequence_average = 1
        self.sequence_flush = 0
        self.sequence_settle = 500

        self.live_dpc_active = False
        self.capture_context = "manual"

        self.optimize_active = False
        self.optimize_candidates = []
        self.optimize_index = 0
        self.optimize_results = []

        self.timelapse_active = False
        self.timelapse_index = 0
        self.timelapse_target = 0

        self.autofocus_active = False
        self.autofocus_positions = []
        self.autofocus_scores = []
        self.autofocus_index = 0
        self.autofocus_current_position = 0

        self.onnx_segmenter = ONNXSegmenter()

        self.init_camera()
        self.init_ui()
        self.load_presets()
        self.connect_tooltips()

        self.live_timer = QTimer(self)
        self.live_timer.timeout.connect(self.update_live_frame)
        self.live_timer.start(30)

        self.apply_preview_light()
        self.update_optics_info()
        self.update_calibration_status()

        print("[System] Advanced DPC GUI initialized")

    # =========================================================
    # Camera and display
    # =========================================================

    def init_camera(self):
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        if self.cap.isOpened():
            print("[Camera] opened")
        else:
            print("[Camera] open failed")

    def update_live_frame(self):
        if self.busy:
            return
        if self.cap is None or not self.cap.isOpened():
            return

        ok, frame = self.cap.read()
        if not ok or frame is None:
            return

        self.current_frame = frame.copy()
        self.frame_counter += 1

        if self.frame_counter % 8 == 0:
            score = focus_score(frame, self.image_label.roi())
            self.focus_live_label.setText(
                "현재 초점 점수: {:.1f}".format(score)
            )

        if str(self.result_combo.currentText()) == "Live":
            self.display_image(self.apply_zoom(frame), "Live")

    def display_image(self, image, name=None):
        if image is None:
            return

        if len(image.shape) == 2:
            display_bgr = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        else:
            display_bgr = image.copy()

        display_bgr = self.ensure_u8(display_bgr)

        rgb = cv2.cvtColor(display_bgr, cv2.COLOR_BGR2RGB)
        height, width, channels = rgb.shape
        bytes_per_line = channels * width

        qimage = QImage(
            rgb.data,
            width,
            height,
            bytes_per_line,
            QImage.Format_RGB888
        ).copy()

        self.image_label.setPixmap(QPixmap.fromImage(qimage))
        self.current_display = display_bgr.copy()

        if name is not None:
            self.current_display_name = str(name)

    @staticmethod
    def ensure_u8(image):
        if image.dtype == np.uint8:
            return image
        finite = image[np.isfinite(image)]
        if finite.size == 0:
            return np.zeros(image.shape, dtype=np.uint8)
        minimum = float(np.percentile(finite, 1.0))
        maximum = float(np.percentile(finite, 99.0))
        if maximum - minimum < 1e-8:
            maximum = minimum + 1.0
        normalized = (image - minimum) / (maximum - minimum)
        return np.clip(normalized * 255.0, 0, 255).astype(np.uint8)

    def apply_zoom(self, frame):
        if frame is None:
            return None

        height, width = frame.shape[:2]
        crop_width = max(1, int(width / self.zoom))
        crop_height = max(1, int(height / self.zoom))
        x1 = max(0, (width - crop_width) // 2)
        y1 = max(0, (height - crop_height) // 2)
        cropped = frame[
            y1:y1 + crop_height,
            x1:x1 + crop_width
        ]
        return cv2.resize(
            cropped,
            (640, 480),
            interpolation=cv2.INTER_LINEAR
        )

    # =========================================================
    # UI construction
    # =========================================================

    def init_ui(self):
        self.setWindowTitle(
            "Sense HAT Advanced DPC Microscope Suite"
        )
        self.resize(900, 1050)

        self.image_label = ROIImageLabel(self)
        self.image_label.setText("카메라 영상을 기다리는 중")
        self.image_label.roiChanged.connect(self.on_roi_changed)

        self.result_combo = QComboBox(self)
        self.result_combo.addItems([
            "Live",
            "DPC X",
            "DPC Y",
            "DPC magnitude",
            "DPC color",
            "Phase-like",
            "OPD estimate",
            "RGB phase",
            "Analysis overlay"
        ])
        self.result_combo.currentIndexChanged.connect(
            self.update_result_display
        )

        self.btn_zoom_in = QPushButton("Zoom +", self)
        self.btn_zoom_out = QPushButton("Zoom -", self)
        self.btn_save_current = QPushButton("현재 영상 저장", self)
        self.btn_clear_roi = QPushButton("ROI 해제", self)

        self.btn_zoom_in.clicked.connect(self.zoom_in)
        self.btn_zoom_out.clicked.connect(self.zoom_out)
        self.btn_save_current.clicked.connect(self.save_current_image)
        self.btn_clear_roi.clicked.connect(self.image_label.clear_roi)

        top_actions = QHBoxLayout()
        top_actions.addWidget(QLabel("표시 결과", self))
        top_actions.addWidget(self.result_combo)
        top_actions.addWidget(self.btn_zoom_in)
        top_actions.addWidget(self.btn_zoom_out)
        top_actions.addWidget(self.btn_clear_roi)
        top_actions.addWidget(self.btn_save_current)

        self.tabs = QTabWidget(self)
        self.tabs.addTab(self.build_live_tab(), "조명/실시간")
        self.tabs.addTab(self.build_acquisition_tab(), "DPC 촬영")
        self.tabs.addTab(self.build_calibration_tab(), "보정")
        self.tabs.addTab(self.build_optimization_tab(), "최적화/초점")
        self.tabs.addTab(self.build_analysis_tab(), "분석/AI")
        self.tabs.addTab(self.build_timelapse_tab(), "타임랩스/프리셋")
        self.tabs.addTab(self.build_help_tab(), "기능 설명")

        self.status_label = QLabel("준비됨", self)
        self.status_label.setAlignment(Qt.AlignCenter)

        self.focus_live_label = QLabel(
            "현재 초점 점수: -",
            self
        )
        self.focus_live_label.setAlignment(Qt.AlignCenter)

        main_layout = QVBoxLayout()
        main_layout.addWidget(self.image_label)
        main_layout.addLayout(top_actions)
        main_layout.addWidget(self.tabs)
        main_layout.addWidget(self.status_label)
        main_layout.addWidget(self.focus_live_label)
        self.setLayout(main_layout)

    def build_live_tab(self):
        tab = QWidget(self)

        self.preview_combo = QComboBox(tab)
        self.preview_combo.addItems([
            "Light off",
            "Bright field",
            "Dark field",
            "DPC left",
            "DPC right",
            "DPC top",
            "DPC bottom",
            "DPC top-left",
            "DPC top-right",
            "DPC bottom-left",
            "DPC bottom-right"
        ])
        self.preview_combo.setCurrentIndex(1)
        self.preview_combo.currentIndexChanged.connect(
            self.apply_preview_light
        )

        self.source_combo = QComboBox(tab)
        self.source_combo.addItems([
            "Half annulus",
            "Half plane"
        ])
        self.source_combo.currentIndexChanged.connect(
            self.apply_preview_light
        )

        self.brightness_slider = QSlider(Qt.Horizontal, tab)
        self.brightness_slider.setRange(1, 255)
        self.brightness_slider.setValue(120)
        self.brightness_slider.valueChanged.connect(
            self.on_light_setting_changed
        )
        self.brightness_value = QLabel("120", tab)

        self.radius_spin = QDoubleSpinBox(tab)
        self.radius_spin.setRange(0.0, 4.5)
        self.radius_spin.setSingleStep(0.1)
        self.radius_spin.setDecimals(1)
        self.radius_spin.setValue(2.2)
        self.radius_spin.valueChanged.connect(
            self.on_light_setting_changed
        )

        self.color_combo = QComboBox(tab)
        self.color_combo.addItems([
            "White",
            "Red",
            "Green",
            "Blue"
        ])
        self.color_combo.currentIndexChanged.connect(
            self.apply_preview_light
        )

        self.btn_live_dpc = QPushButton(
            "실시간 DPC 시작",
            tab
        )
        self.btn_live_dpc.clicked.connect(
            self.toggle_live_dpc
        )

        self.btn_auto_exposure = QPushButton(
            "카메라 자동 노출",
            tab
        )
        self.btn_lock_exposure = QPushButton(
            "노출/화이트밸런스 고정",
            tab
        )
        self.btn_auto_exposure.clicked.connect(
            self.enable_auto_exposure
        )
        self.btn_lock_exposure.clicked.connect(
            self.lock_camera_controls
        )

        self.roi_status_label = QLabel("ROI: 전체 영상", tab)

        layout = QGridLayout()
        layout.addWidget(QLabel("미리보기 조명", tab), 0, 0)
        layout.addWidget(self.preview_combo, 0, 1)
        layout.addWidget(QLabel("DPC 광원 형태", tab), 0, 2)
        layout.addWidget(self.source_combo, 0, 3)

        layout.addWidget(QLabel("LED 밝기", tab), 1, 0)
        layout.addWidget(self.brightness_slider, 1, 1, 1, 2)
        layout.addWidget(self.brightness_value, 1, 3)

        layout.addWidget(QLabel("중앙 차광 반지름", tab), 2, 0)
        layout.addWidget(self.radius_spin, 2, 1)
        layout.addWidget(QLabel("LED 색", tab), 2, 2)
        layout.addWidget(self.color_combo, 2, 3)

        layout.addWidget(self.btn_live_dpc, 3, 0, 1, 2)
        layout.addWidget(self.btn_auto_exposure, 3, 2)
        layout.addWidget(self.btn_lock_exposure, 3, 3)
        layout.addWidget(self.roi_status_label, 4, 0, 1, 4)

        tab.setLayout(layout)
        return tab

    def build_acquisition_tab(self):
        tab = QWidget(self)

        self.direction_combo = QComboBox(tab)
        self.direction_combo.addItems([
            "4 directions",
            "8 directions"
        ])

        self.rgb_check = QCheckBox("RGB-DPC 촬영", tab)

        self.average_spin = QSpinBox(tab)
        self.average_spin.setRange(1, 20)
        self.average_spin.setValue(4)

        self.flush_spin = QSpinBox(tab)
        self.flush_spin.setRange(0, 30)
        self.flush_spin.setValue(6)

        self.settle_spin = QSpinBox(tab)
        self.settle_spin.setRange(100, 3000)
        self.settle_spin.setSingleStep(50)
        self.settle_spin.setValue(700)

        self.registration_check = QCheckBox(
            "방향 영상 자동 정렬",
            tab
        )
        self.registration_check.setChecked(True)

        self.registration_combo = QComboBox(tab)
        self.registration_combo.addItems([
            "Phase correlation",
            "ECC"
        ])

        self.apply_calibration_check = QCheckBox(
            "Dark/Flat 보정 적용",
            tab
        )
        self.apply_calibration_check.setChecked(True)

        self.invert_x_check = QCheckBox("Invert X", tab)
        self.invert_y_check = QCheckBox("Invert Y", tab)

        self.regularization_spin = QDoubleSpinBox(tab)
        self.regularization_spin.setRange(0.000001, 1.0)
        self.regularization_spin.setDecimals(6)
        self.regularization_spin.setSingleStep(0.0005)
        self.regularization_spin.setValue(0.002)
        self.regularization_spin.valueChanged.connect(
            self.recompute_results
        )

        self.wavelength_spin = QDoubleSpinBox(tab)
        self.wavelength_spin.setRange(350.0, 800.0)
        self.wavelength_spin.setValue(550.0)
        self.wavelength_spin.setSuffix(" nm")
        self.wavelength_spin.valueChanged.connect(
            self.recompute_results
        )

        self.phase_scale_spin = QDoubleSpinBox(tab)
        self.phase_scale_spin.setRange(0.0001, 100.0)
        self.phase_scale_spin.setDecimals(4)
        self.phase_scale_spin.setValue(1.0)
        self.phase_scale_spin.valueChanged.connect(
            self.recompute_results
        )

        self.btn_capture_dpc = QPushButton("DPC 촬영", tab)
        self.btn_capture_dpc.clicked.connect(
            lambda: self.start_dpc_capture("manual")
        )

        self.btn_cancel_task = QPushButton("현재 작업 중지", tab)
        self.btn_cancel_task.clicked.connect(self.cancel_current_task)

        self.capture_progress = QProgressBar(tab)
        self.capture_progress.setValue(0)

        self.diagnostics_table = QTableWidget(0, 3, tab)
        self.diagnostics_table.setHorizontalHeaderLabels([
            "항목",
            "값",
            "판정"
        ])
        self.diagnostics_table.horizontalHeader().setResizeMode(
            QHeaderView.Stretch
        )
        self.diagnostics_table.setMaximumHeight(180)

        layout = QGridLayout()
        layout.addWidget(QLabel("방향 수", tab), 0, 0)
        layout.addWidget(self.direction_combo, 0, 1)
        layout.addWidget(self.rgb_check, 0, 2, 1, 2)

        layout.addWidget(QLabel("평균 프레임", tab), 1, 0)
        layout.addWidget(self.average_spin, 1, 1)
        layout.addWidget(QLabel("버릴 프레임", tab), 1, 2)
        layout.addWidget(self.flush_spin, 1, 3)

        layout.addWidget(QLabel("조명 안정 시간", tab), 2, 0)
        layout.addWidget(self.settle_spin, 2, 1)
        layout.addWidget(self.registration_check, 2, 2)
        layout.addWidget(self.registration_combo, 2, 3)

        layout.addWidget(self.apply_calibration_check, 3, 0, 1, 2)
        layout.addWidget(self.invert_x_check, 3, 2)
        layout.addWidget(self.invert_y_check, 3, 3)

        layout.addWidget(QLabel("Phase regularization", tab), 4, 0)
        layout.addWidget(self.regularization_spin, 4, 1)
        layout.addWidget(QLabel("파장", tab), 4, 2)
        layout.addWidget(self.wavelength_spin, 4, 3)

        layout.addWidget(QLabel("Phase scale", tab), 5, 0)
        layout.addWidget(self.phase_scale_spin, 5, 1)
        layout.addWidget(self.btn_capture_dpc, 5, 2)
        layout.addWidget(self.btn_cancel_task, 5, 3)

        layout.addWidget(self.capture_progress, 6, 0, 1, 4)
        layout.addWidget(self.diagnostics_table, 7, 0, 1, 4)

        tab.setLayout(layout)
        return tab

    def build_calibration_tab(self):
        tab = QWidget(self)

        self.btn_capture_dark = QPushButton(
            "Dark reference 촬영",
            tab
        )
        self.btn_capture_flat = QPushButton(
            "Flat reference 촬영",
            tab
        )
        self.btn_led_calibration = QPushButton(
            "64 LED 밝기 보정",
            tab
        )
        self.btn_save_calibration = QPushButton(
            "보정 파일 저장",
            tab
        )
        self.btn_load_calibration = QPushButton(
            "보정 파일 불러오기",
            tab
        )
        self.btn_reset_calibration = QPushButton(
            "보정 초기화",
            tab
        )

        self.btn_capture_dark.clicked.connect(
            self.capture_dark_reference
        )
        self.btn_capture_flat.clicked.connect(
            self.capture_flat_reference
        )
        self.btn_led_calibration.clicked.connect(
            self.start_led_calibration
        )
        self.btn_save_calibration.clicked.connect(
            self.save_calibration
        )
        self.btn_load_calibration.clicked.connect(
            self.load_calibration
        )
        self.btn_reset_calibration.clicked.connect(
            self.reset_calibration
        )

        self.calibration_status = QTextBrowser(tab)
        self.calibration_status.setMaximumHeight(180)

        explanation = QTextBrowser(tab)
        explanation.setHtml(
            "<b>Dark</b>: LED를 끈 상태의 카메라 오프셋과 주변광을 측정합니다.<br>"
            "<b>Flat</b>: 시료 없는 빈 슬라이드에서 방향별 조명 불균일을 측정합니다.<br>"
            "<b>LED calibration</b>: 64개 LED를 하나씩 켜 상대 밝기 계수를 계산합니다."
        )
        explanation.setMaximumHeight(110)

        layout = QGridLayout()
        layout.addWidget(self.btn_capture_dark, 0, 0)
        layout.addWidget(self.btn_capture_flat, 0, 1)
        layout.addWidget(self.btn_led_calibration, 0, 2)

        layout.addWidget(self.btn_save_calibration, 1, 0)
        layout.addWidget(self.btn_load_calibration, 1, 1)
        layout.addWidget(self.btn_reset_calibration, 1, 2)

        layout.addWidget(self.calibration_status, 2, 0, 1, 3)
        layout.addWidget(explanation, 3, 0, 1, 3)

        tab.setLayout(layout)
        return tab

    def build_optimization_tab(self):
        tab = QWidget(self)

        self.btn_auto_optimize = QPushButton(
            "DPC 조건 자동 최적화",
            tab
        )
        self.btn_auto_optimize.clicked.connect(
            self.start_auto_optimize
        )

        self.optimize_exposure_check = QCheckBox(
            "노출값 후보도 탐색",
            tab
        )

        self.optimize_status = QTextBrowser(tab)
        self.optimize_status.setMaximumHeight(150)

        self.focus_command_edit = QLineEdit(tab)
        self.focus_command_edit.setPlaceholderText(
            "예: python3 stage.py {delta}"
        )

        self.focus_range_spin = QSpinBox(tab)
        self.focus_range_spin.setRange(1, 20)
        self.focus_range_spin.setValue(5)

        self.focus_step_spin = QSpinBox(tab)
        self.focus_step_spin.setRange(1, 10000)
        self.focus_step_spin.setValue(20)

        self.focus_settle_spin = QSpinBox(tab)
        self.focus_settle_spin.setRange(100, 5000)
        self.focus_settle_spin.setValue(500)

        self.btn_autofocus = QPushButton(
            "외부 Z축 자동 초점",
            tab
        )
        self.btn_autofocus.clicked.connect(
            self.start_autofocus
        )

        self.camera_pixel_spin = QDoubleSpinBox(tab)
        self.camera_pixel_spin.setRange(0.1, 20.0)
        self.camera_pixel_spin.setValue(3.75)
        self.camera_pixel_spin.setSuffix(" um")
        self.camera_pixel_spin.valueChanged.connect(
            self.update_optics_info
        )

        self.magnification_spin = QDoubleSpinBox(tab)
        self.magnification_spin.setRange(1.0, 100.0)
        self.magnification_spin.setValue(10.0)
        self.magnification_spin.setSuffix(" x")
        self.magnification_spin.valueChanged.connect(
            self.update_optics_info
        )

        self.objective_na_spin = QDoubleSpinBox(tab)
        self.objective_na_spin.setRange(0.01, 1.5)
        self.objective_na_spin.setDecimals(3)
        self.objective_na_spin.setValue(0.25)
        self.objective_na_spin.valueChanged.connect(
            self.update_optics_info
        )

        self.led_pitch_spin = QDoubleSpinBox(tab)
        self.led_pitch_spin.setRange(0.1, 20.0)
        self.led_pitch_spin.setValue(3.0)
        self.led_pitch_spin.setSuffix(" mm")
        self.led_pitch_spin.valueChanged.connect(
            self.update_optics_info
        )

        self.led_distance_spin = QDoubleSpinBox(tab)
        self.led_distance_spin.setRange(1.0, 200.0)
        self.led_distance_spin.setValue(20.0)
        self.led_distance_spin.setSuffix(" mm")
        self.led_distance_spin.valueChanged.connect(
            self.update_optics_info
        )

        self.optics_info_label = QLabel("-", tab)
        self.optics_info_label.setWordWrap(True)

        layout = QGridLayout()
        layout.addWidget(self.btn_auto_optimize, 0, 0, 1, 2)
        layout.addWidget(self.optimize_exposure_check, 0, 2, 1, 2)
        layout.addWidget(self.optimize_status, 1, 0, 1, 4)

        layout.addWidget(QLabel("Z축 명령 템플릿", tab), 2, 0)
        layout.addWidget(self.focus_command_edit, 2, 1, 1, 3)

        layout.addWidget(QLabel("양쪽 탐색 단계", tab), 3, 0)
        layout.addWidget(self.focus_range_spin, 3, 1)
        layout.addWidget(QLabel("단계당 이동량", tab), 3, 2)
        layout.addWidget(self.focus_step_spin, 3, 3)

        layout.addWidget(QLabel("이동 후 대기", tab), 4, 0)
        layout.addWidget(self.focus_settle_spin, 4, 1)
        layout.addWidget(self.btn_autofocus, 4, 2, 1, 2)

        layout.addWidget(QLabel("카메라 픽셀", tab), 5, 0)
        layout.addWidget(self.camera_pixel_spin, 5, 1)
        layout.addWidget(QLabel("배율", tab), 5, 2)
        layout.addWidget(self.magnification_spin, 5, 3)

        layout.addWidget(QLabel("대물렌즈 NA", tab), 6, 0)
        layout.addWidget(self.objective_na_spin, 6, 1)
        layout.addWidget(QLabel("LED 간격", tab), 6, 2)
        layout.addWidget(self.led_pitch_spin, 6, 3)

        layout.addWidget(QLabel("LED-시료 거리", tab), 7, 0)
        layout.addWidget(self.led_distance_spin, 7, 1)
        layout.addWidget(self.optics_info_label, 8, 0, 1, 4)

        tab.setLayout(layout)
        return tab

    def build_analysis_tab(self):
        tab = QWidget(self)

        self.analysis_source_combo = QComboBox(tab)
        self.analysis_source_combo.addItems([
            "현재 표시 영상",
            "Live",
            "DPC magnitude",
            "Phase-like",
            "OPD estimate"
        ])

        self.threshold_spin = QSpinBox(tab)
        self.threshold_spin.setRange(0, 255)
        self.threshold_spin.setValue(0)

        self.min_area_spin = QSpinBox(tab)
        self.min_area_spin.setRange(1, 100000)
        self.min_area_spin.setValue(20)

        self.max_area_spin = QSpinBox(tab)
        self.max_area_spin.setRange(10, 10000000)
        self.max_area_spin.setValue(100000)

        self.segment_invert_check = QCheckBox(
            "임계값 반전",
            tab
        )

        self.btn_classical_analysis = QPushButton(
            "세포/입자 윤곽 분석",
            tab
        )
        self.btn_classical_analysis.clicked.connect(
            self.run_classical_analysis
        )

        self.onnx_path_edit = QLineEdit(tab)
        self.btn_load_onnx = QPushButton(
            "ONNX 모델 불러오기",
            tab
        )
        self.btn_load_onnx.clicked.connect(
            self.load_onnx_model
        )

        self.onnx_width_spin = QSpinBox(tab)
        self.onnx_width_spin.setRange(32, 2048)
        self.onnx_width_spin.setValue(256)

        self.onnx_height_spin = QSpinBox(tab)
        self.onnx_height_spin.setRange(32, 2048)
        self.onnx_height_spin.setValue(256)

        self.onnx_threshold_spin = QDoubleSpinBox(tab)
        self.onnx_threshold_spin.setRange(0.0, 1.0)
        self.onnx_threshold_spin.setSingleStep(0.05)
        self.onnx_threshold_spin.setValue(0.5)

        self.btn_run_onnx = QPushButton(
            "ONNX 분할 실행",
            tab
        )
        self.btn_run_onnx.clicked.connect(
            self.run_onnx_analysis
        )

        self.analysis_result_browser = QTextBrowser(tab)
        self.analysis_result_browser.setMaximumHeight(180)

        layout = QGridLayout()
        layout.addWidget(QLabel("분석 영상", tab), 0, 0)
        layout.addWidget(self.analysis_source_combo, 0, 1)
        layout.addWidget(QLabel("임계값(0=Otsu)", tab), 0, 2)
        layout.addWidget(self.threshold_spin, 0, 3)

        layout.addWidget(QLabel("최소 면적", tab), 1, 0)
        layout.addWidget(self.min_area_spin, 1, 1)
        layout.addWidget(QLabel("최대 면적", tab), 1, 2)
        layout.addWidget(self.max_area_spin, 1, 3)

        layout.addWidget(self.segment_invert_check, 2, 0)
        layout.addWidget(self.btn_classical_analysis, 2, 1, 1, 3)

        layout.addWidget(QLabel("ONNX 모델", tab), 3, 0)
        layout.addWidget(self.onnx_path_edit, 3, 1, 1, 2)
        layout.addWidget(self.btn_load_onnx, 3, 3)

        layout.addWidget(QLabel("입력 폭", tab), 4, 0)
        layout.addWidget(self.onnx_width_spin, 4, 1)
        layout.addWidget(QLabel("입력 높이", tab), 4, 2)
        layout.addWidget(self.onnx_height_spin, 4, 3)

        layout.addWidget(QLabel("AI 임계값", tab), 5, 0)
        layout.addWidget(self.onnx_threshold_spin, 5, 1)
        layout.addWidget(self.btn_run_onnx, 5, 2, 1, 2)

        layout.addWidget(self.analysis_result_browser, 6, 0, 1, 4)

        tab.setLayout(layout)
        return tab

    def build_timelapse_tab(self):
        tab = QWidget(self)

        self.timelapse_interval_spin = QDoubleSpinBox(tab)
        self.timelapse_interval_spin.setRange(1.0, 86400.0)
        self.timelapse_interval_spin.setValue(10.0)
        self.timelapse_interval_spin.setSuffix(" s")

        self.timelapse_count_spin = QSpinBox(tab)
        self.timelapse_count_spin.setRange(0, 100000)
        self.timelapse_count_spin.setValue(10)

        self.btn_timelapse = QPushButton(
            "타임랩스 시작",
            tab
        )
        self.btn_timelapse.clicked.connect(
            self.toggle_timelapse
        )

        self.timelapse_status_label = QLabel(
            "타임랩스: 대기",
            tab
        )

        self.preset_combo = QComboBox(tab)
        self.preset_name_edit = QLineEdit(tab)
        self.preset_name_edit.setPlaceholderText(
            "새 프리셋 이름"
        )

        self.btn_apply_preset = QPushButton(
            "프리셋 적용",
            tab
        )
        self.btn_save_preset = QPushButton(
            "현재 설정 저장",
            tab
        )
        self.btn_delete_preset = QPushButton(
            "프리셋 삭제",
            tab
        )

        self.btn_apply_preset.clicked.connect(
            self.apply_selected_preset
        )
        self.btn_save_preset.clicked.connect(
            self.save_current_preset
        )
        self.btn_delete_preset.clicked.connect(
            self.delete_selected_preset
        )

        self.save_raw_check = QCheckBox(
            "방향별 원본 프레임 저장",
            tab
        )
        self.save_raw_check.setChecked(True)

        self.save_float_check = QCheckBox(
            "DPC 실수 배열 NPZ 저장",
            tab
        )
        self.save_float_check.setChecked(True)

        explanation = QTextBrowser(tab)
        explanation.setHtml(
            "<b>타임랩스</b>: 지정 간격으로 DPC를 반복 촬영하고 자동 저장합니다.<br>"
            "<b>프리셋</b>: 시료와 대물렌즈별 조명·촬영·복원 설정을 저장합니다.<br>"
            "촬영 횟수 0은 사용자가 중지할 때까지 계속한다는 뜻입니다."
        )
        explanation.setMaximumHeight(110)

        layout = QGridLayout()
        layout.addWidget(QLabel("촬영 간격", tab), 0, 0)
        layout.addWidget(self.timelapse_interval_spin, 0, 1)
        layout.addWidget(QLabel("촬영 횟수(0=무한)", tab), 0, 2)
        layout.addWidget(self.timelapse_count_spin, 0, 3)

        layout.addWidget(self.btn_timelapse, 1, 0, 1, 2)
        layout.addWidget(self.timelapse_status_label, 1, 2, 1, 2)

        layout.addWidget(QLabel("프리셋", tab), 2, 0)
        layout.addWidget(self.preset_combo, 2, 1)
        layout.addWidget(self.btn_apply_preset, 2, 2)
        layout.addWidget(self.btn_delete_preset, 2, 3)

        layout.addWidget(self.preset_name_edit, 3, 0, 1, 2)
        layout.addWidget(self.btn_save_preset, 3, 2, 1, 2)

        layout.addWidget(self.save_raw_check, 4, 0, 1, 2)
        layout.addWidget(self.save_float_check, 4, 2, 1, 2)
        layout.addWidget(explanation, 5, 0, 1, 4)

        tab.setLayout(layout)
        return tab

    def build_help_tab(self):
        tab = QWidget(self)

        self.help_topic_combo = QComboBox(tab)
        for topic in HELP_TOPICS.keys():
            self.help_topic_combo.addItem(topic)

        self.help_browser = QTextBrowser(tab)
        self.help_topic_combo.currentIndexChanged.connect(
            self.update_help_topic
        )

        layout = QVBoxLayout()
        layout.addWidget(self.help_topic_combo)
        layout.addWidget(self.help_browser)
        tab.setLayout(layout)

        self.update_help_topic()
        return tab

    def connect_tooltips(self):
        self.btn_live_dpc.setToolTip(
            "방향 조명을 반복 촬영해 저속 DPC 결과를 연속 갱신합니다."
        )
        self.registration_check.setToolTip(
            "조명 전환 사이의 미세한 시료 이동을 보정합니다."
        )
        self.btn_capture_dark.setToolTip(
            "LED를 끈 상태의 카메라 오프셋과 주변광을 측정합니다."
        )
        self.btn_capture_flat.setToolTip(
            "빈 슬라이드에서 각 방향의 조명 불균일을 측정합니다."
        )
        self.btn_led_calibration.setToolTip(
            "64개 LED를 하나씩 측정해 밝기 계수를 보정합니다."
        )
        self.btn_auto_optimize.setToolTip(
            "밝기, 차광 반지름, 광원 형태를 자동 비교합니다."
        )
        self.btn_autofocus.setToolTip(
            "외부 Z축 이동 명령이 설정된 경우 초점 점수가 최대인 위치를 찾습니다."
        )
        self.rgb_check.setToolTip(
            "빨강·초록·파랑 LED로 각각 DPC를 촬영합니다."
        )

    # =========================================================
    # Preview illumination and camera controls
    # =========================================================

    def source_mode(self):
        if str(self.source_combo.currentText()) == "Half plane":
            return "half_plane"
        return "half_annulus"

    def selected_color_name(self):
        return str(self.color_combo.currentText()).lower()

    def on_light_setting_changed(self, value=None):
        self.brightness_value.setText(
            str(self.brightness_slider.value())
        )
        self.update_optics_info()
        self.apply_preview_light()

    def apply_preview_light(self, value=None):
        if self.busy:
            return

        name = str(self.preview_combo.currentText())
        brightness = self.brightness_slider.value()
        radius = self.radius_spin.value()
        source = self.source_mode()
        color = self.selected_color_name()

        name_mapping = {
            "Light off": "off",
            "Bright field": "brightfield",
            "Dark field": "darkfield",
            "DPC left": "left",
            "DPC right": "right",
            "DPC top": "top",
            "DPC bottom": "bottom",
            "DPC top-left": "top_left",
            "DPC top-right": "top_right",
            "DPC bottom-left": "bottom_left",
            "DPC bottom-right": "bottom_right",
        }

        pattern_name = name_mapping.get(name, "off")
        pixels = self.led.pattern_for_name(
            pattern_name,
            brightness,
            radius,
            source,
            color
        )
        self.led.apply(pixels, pattern_name)
        self.status_label.setText(
            "조명: {} | 밝기 {} | 색 {}".format(
                pattern_name,
                brightness,
                color
            )
        )

    def enable_auto_exposure(self):
        if self.cap is None:
            return
        exposure_ok = self.cap.set(
            cv2.CAP_PROP_AUTO_EXPOSURE,
            0.75
        )
        wb_ok = self.cap.set(
            cv2.CAP_PROP_AUTO_WB,
            1
        )
        self.status_label.setText(
            "자동 노출 요청 {} | 자동 WB 요청 {}".format(
                exposure_ok,
                wb_ok
            )
        )

    def lock_camera_controls(self):
        if self.cap is None:
            return

        exposure = self.cap.get(cv2.CAP_PROP_EXPOSURE)
        manual_ok = self.cap.set(
            cv2.CAP_PROP_AUTO_EXPOSURE,
            0.25
        )
        self.cap.set(cv2.CAP_PROP_AUTO_WB, 0)

        if exposure not in (-1, 0):
            self.cap.set(
                cv2.CAP_PROP_EXPOSURE,
                exposure
            )

        self.status_label.setText(
            "노출 고정 요청 {} | exposure {}".format(
                manual_ok,
                exposure
            )
        )

    # =========================================================
    # Generic sequence acquisition
    # =========================================================

    def start_sequence(
        self,
        sequence,
        callback,
        purpose,
        average_frames=None,
        flush_frames=None,
        settle_ms=None
    ):
        if self.busy:
            return False

        if self.cap is None or not self.cap.isOpened():
            QMessageBox.warning(
                self,
                "카메라 오류",
                "카메라가 열려 있지 않습니다."
            )
            return False

        if not self.led.available:
            QMessageBox.warning(
                self,
                "Sense HAT 오류",
                "Sense HAT LED를 사용할 수 없습니다."
            )
            return False

        self.busy = True
        self.sequence = list(sequence)
        self.sequence_index = 0
        self.sequence_frames = {}
        self.sequence_callback = callback
        self.sequence_purpose = str(purpose)
        self.sequence_average = int(
            average_frames
            if average_frames is not None
            else self.average_spin.value()
        )
        self.sequence_flush = int(
            flush_frames
            if flush_frames is not None
            else self.flush_spin.value()
        )
        self.sequence_settle = int(
            settle_ms
            if settle_ms is not None
            else self.settle_spin.value()
        )

        self.capture_progress.setRange(
            0,
            len(self.sequence)
        )
        self.capture_progress.setValue(0)

        self.run_sequence_item()
        return True

    def run_sequence_item(self):
        if not self.busy:
            return

        if self.sequence_index >= len(self.sequence):
            callback = self.sequence_callback
            frames = dict(self.sequence_frames)
            purpose = self.sequence_purpose

            self.busy = False
            self.sequence = []
            self.sequence_callback = None

            if callback is not None:
                callback(frames, purpose)
            return

        item = self.sequence[self.sequence_index]
        self.led.apply(item["pixels"], item["name"])
        self.status_label.setText(
            "{} {}/{}: {}".format(
                self.sequence_purpose,
                self.sequence_index + 1,
                len(self.sequence),
                item["name"]
            )
        )

        QTimer.singleShot(
            self.sequence_settle,
            self.capture_sequence_item
        )

    def capture_sequence_item(self):
        if not self.busy:
            return

        item = self.sequence[self.sequence_index]

        for _ in range(self.sequence_flush):
            self.cap.read()

        frames = []
        for _ in range(self.sequence_average):
            ok, frame = self.cap.read()
            if ok and frame is not None:
                frames.append(frame.astype(np.float32))

        if not frames:
            self.status_label.setText(
                "카메라 프레임을 읽지 못했습니다."
            )
            self.cancel_current_task()
            return

        mean_frame = np.mean(frames, axis=0)
        mean_frame = np.clip(
            mean_frame,
            0,
            255
        ).astype(np.uint8)

        self.sequence_frames[item["name"]] = mean_frame
        self.display_image(
            self.apply_zoom(mean_frame),
            item["name"]
        )

        self.sequence_index += 1
        self.capture_progress.setValue(
            self.sequence_index
        )

        QTimer.singleShot(20, self.run_sequence_item)

    def cancel_current_task(self):
        self.busy = False
        self.sequence = []
        self.sequence_callback = None
        self.optimize_active = False
        self.autofocus_active = False
        self.live_dpc_active = False
        self.timelapse_active = False
        self.btn_live_dpc.setText("실시간 DPC 시작")
        self.btn_timelapse.setText("타임랩스 시작")
        self.apply_preview_light()
        self.status_label.setText("작업이 중지되었습니다.")

    # =========================================================
    # DPC sequence and processing
    # =========================================================

    def direction_count(self):
        if str(self.direction_combo.currentText()) == "8 directions":
            return 8
        return 4

    def build_dpc_sequence(
        self,
        direction_count=None,
        rgb=None,
        brightness=None,
        radius=None,
        source_mode=None
    ):
        direction_count = (
            self.direction_count()
            if direction_count is None
            else int(direction_count)
        )
        rgb = self.rgb_check.isChecked() if rgb is None else bool(rgb)
        brightness = (
            self.brightness_slider.value()
            if brightness is None
            else int(brightness)
        )
        radius = (
            self.radius_spin.value()
            if radius is None
            else float(radius)
        )
        source_mode = (
            self.source_mode()
            if source_mode is None
            else str(source_mode)
        )

        directions = (
            self.FOUR_DIRECTIONS
            if direction_count == 4
            else self.EIGHT_DIRECTIONS
        )

        colors = ["white"]
        if rgb:
            colors = ["red", "green", "blue"]

        sequence = []

        for color in colors:
            for direction in directions:
                name = (
                    direction
                    if color == "white"
                    else color + "_" + direction
                )
                pixels = self.led.pattern_for_name(
                    direction,
                    brightness,
                    radius,
                    source_mode,
                    color
                )
                sequence.append({
                    "name": name,
                    "direction": direction,
                    "color": color,
                    "pixels": pixels
                })

        return sequence

    def start_dpc_capture(self, context="manual"):
        if self.busy:
            return

        self.capture_context = str(context)
        self.lock_camera_controls()

        sequence = self.build_dpc_sequence()
        self.start_sequence(
            sequence,
            self.on_dpc_sequence_complete,
            "DPC 촬영"
        )

    def on_dpc_sequence_complete(self, frames, purpose):
        try:
            self.process_dpc_frames(frames)
        except Exception as error:
            self.status_label.setText(
                "DPC 처리 오류: " + repr(error)
            )
            print("[DPC] processing error:", repr(error))
            self.apply_preview_light()
            return

        if self.capture_context == "live":
            if self.live_dpc_active:
                QTimer.singleShot(
                    50,
                    lambda: self.start_dpc_capture("live")
                )
            return

        if self.capture_context == "timelapse":
            self.save_result_bundle(
                prefix="timelapse_{:05d}".format(
                    self.timelapse_index
                )
            )
            self.timelapse_index += 1
            self.update_timelapse_after_capture()
            return

        self.apply_preview_light()
        self.status_label.setText("DPC 촬영과 처리가 완료되었습니다.")

    def process_dpc_frames(self, frames):
        self.last_raw_frames = dict(frames)

        if self.rgb_check.isChecked():
            color_results = {}
            rgb_phase_channels = {}

            for color in ["red", "green", "blue"]:
                group = {}
                for name, frame in frames.items():
                    prefix = color + "_"
                    if name.startswith(prefix):
                        direction = name[len(prefix):]
                        group[direction] = frame

                result = self.process_single_color_group(
                    group,
                    color,
                    prefix=color + "_"
                )
                color_results[color] = result
                rgb_phase_channels[color] = result["phase_u8"]

            rgb_phase = cv2.merge([
                rgb_phase_channels["blue"],
                rgb_phase_channels["green"],
                rgb_phase_channels["red"]
            ])
            self.result_images["RGB phase"] = rgb_phase

            base_result = color_results["green"]
            self.update_result_storage(base_result)
        else:
            result = self.process_single_color_group(
                frames,
                "white",
                prefix=""
            )
            self.update_result_storage(result)

        self.result_combo.setCurrentIndex(
            self.result_combo.findText("DPC color")
        )
        self.update_result_display()
        self.update_diagnostics_table()

    def process_single_color_group(
        self,
        frames,
        color_name,
        prefix=""
    ):
        prepared = {}

        for direction, frame in frames.items():
            gray = to_gray(frame, color_name)

            dark_gray = None
            if self.dark_frame is not None:
                dark_gray = to_gray(
                    self.dark_frame,
                    color_name
                )

            flat_gray = None
            full_key = prefix + direction
            if full_key in self.flat_frames:
                flat_gray = to_gray(
                    self.flat_frames[full_key],
                    color_name
                )

            if self.apply_calibration_check.isChecked():
                gray = correct_frame(
                    gray,
                    dark_gray,
                    flat_gray
                )

            prepared[direction] = gray.astype(np.float32)

        shifts = {}
        if self.registration_check.isChecked():
            method = (
                "ecc"
                if str(self.registration_combo.currentText()) == "ECC"
                else "phase"
            )
            prepared, shifts = register_frames(
                prepared,
                method
            )

        if self.direction_count() == 8:
            gx, gy = compute_dpc_8(
                prepared,
                self.invert_x_check.isChecked(),
                self.invert_y_check.isChecked()
            )
        else:
            gx, gy = compute_dpc_4(
                prepared,
                self.invert_x_check.isChecked(),
                self.invert_y_check.isChecked()
            )

        magnitude = np.sqrt(gx ** 2 + gy ** 2)
        phase = integrate_gradients_fft(
            gx,
            gy,
            self.regularization_spin.value()
        )
        opd = opd_from_phase_like(
            phase,
            self.wavelength_spin.value(),
            self.phase_scale_spin.value()
        )

        source_frame = list(frames.values())[0]
        quality = dpc_quality(
            gx,
            gy,
            source_frame,
            shifts,
            self.image_label.roi()
        )

        self.last_registration = shifts
        self.last_quality = quality

        return {
            "gx": gx,
            "gy": gy,
            "magnitude": magnitude,
            "phase": phase,
            "opd": opd,
            "gx_u8": signed_to_u8(gx),
            "gy_u8": signed_to_u8(gy),
            "magnitude_u8": positive_to_u8(magnitude),
            "color_u8": dpc_color(gx, gy),
            "phase_u8": signed_to_u8(phase),
            "opd_u8": signed_to_u8(opd),
            "quality": quality,
            "shifts": shifts
        }

    def update_result_storage(self, result):
        self.result_float["dpc_x"] = result["gx"]
        self.result_float["dpc_y"] = result["gy"]
        self.result_float["magnitude"] = result["magnitude"]
        self.result_float["phase_like"] = result["phase"]
        self.result_float["opd_nm_estimate"] = result["opd"]

        self.result_images["DPC X"] = result["gx_u8"]
        self.result_images["DPC Y"] = result["gy_u8"]
        self.result_images["DPC magnitude"] = result["magnitude_u8"]
        self.result_images["DPC color"] = result["color_u8"]
        self.result_images["Phase-like"] = result["phase_u8"]
        self.result_images["OPD estimate"] = result["opd_u8"]

    def recompute_results(self, value=None):
        if not self.last_raw_frames:
            return
        if self.busy:
            return
        try:
            self.process_dpc_frames(self.last_raw_frames)
        except Exception:
            pass

    def update_result_display(self, value=None):
        mode = str(self.result_combo.currentText())

        if mode == "Live":
            if self.current_frame is not None:
                self.display_image(
                    self.apply_zoom(self.current_frame),
                    "Live"
                )
            return

        if mode not in self.result_images:
            self.status_label.setText(
                "해당 결과가 아직 생성되지 않았습니다."
            )
            return

        self.display_image(
            self.apply_zoom(self.result_images[mode]),
            mode
        )

    def toggle_live_dpc(self):
        if self.live_dpc_active:
            self.live_dpc_active = False
            self.btn_live_dpc.setText("실시간 DPC 시작")
            self.status_label.setText("실시간 DPC를 중지했습니다.")
            return

        if self.busy:
            return

        self.live_dpc_active = True
        self.btn_live_dpc.setText("실시간 DPC 중지")
        self.start_dpc_capture("live")

    # =========================================================
    # Diagnostics
    # =========================================================

    def update_diagnostics_table(self):
        quality = self.last_quality
        if not quality:
            return

        rows = [
            (
                "품질 점수",
                "{:.1f}".format(quality.get("score", 0.0)),
                "좋음" if quality.get("score", 0.0) >= 65 else "점검"
            ),
            (
                "SNR",
                "{:.2f}".format(quality.get("snr", 0.0)),
                "좋음" if quality.get("snr", 0.0) >= 3 else "낮음"
            ),
            (
                "포화 비율",
                "{:.2%}".format(quality.get("saturation", 0.0)),
                "좋음" if quality.get("saturation", 0.0) < 0.02 else "과노출"
            ),
            (
                "저노출 비율",
                "{:.2%}".format(quality.get("underexposure", 0.0)),
                "좋음" if quality.get("underexposure", 0.0) < 0.10 else "어두움"
            ),
            (
                "초점 점수",
                "{:.1f}".format(quality.get("focus", 0.0)),
                "참고값"
            ),
            (
                "최대 이동량",
                "{:.2f} px".format(quality.get("max_motion", 0.0)),
                "좋음" if quality.get("max_motion", 0.0) < 2.0 else "재촬영 권장"
            ),
            (
                "DPC 크기 P95",
                "{:.4f}".format(quality.get("p95_magnitude", 0.0)),
                "참고값"
            )
        ]

        self.diagnostics_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.diagnostics_table.setItem(
                    row_index,
                    column_index,
                    QTableWidgetItem(str(value))
                )

    # =========================================================
    # Calibration
    # =========================================================

    def capture_dark_reference(self):
        if self.busy:
            return

        QMessageBox.information(
            self,
            "Dark reference",
            "주변광을 가능한 한 차단하고 LED를 끈 상태로 촬영합니다."
        )

        sequence = [{
            "name": "dark",
            "pixels": self.led.off_pattern()
        }]
        self.start_sequence(
            sequence,
            self.on_dark_complete,
            "Dark reference",
            average_frames=12,
            flush_frames=4,
            settle_ms=500
        )

    def on_dark_complete(self, frames, purpose):
        self.dark_frame = frames["dark"]
        self.calibration_metadata["dark_time"] = (
            datetime.datetime.now().isoformat()
        )
        self.update_calibration_status()
        self.apply_preview_light()
        self.status_label.setText("Dark reference가 저장되었습니다.")

    def capture_flat_reference(self):
        if self.busy:
            return

        answer = QMessageBox.question(
            self,
            "Flat reference",
            "시료를 제거하고 빈 슬라이드만 놓았습니까?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if answer != QMessageBox.Yes:
            return

        sequence = self.build_dpc_sequence()
        self.start_sequence(
            sequence,
            self.on_flat_complete,
            "Flat reference",
            average_frames=max(6, self.average_spin.value()),
            flush_frames=self.flush_spin.value(),
            settle_ms=self.settle_spin.value()
        )

    def on_flat_complete(self, frames, purpose):
        self.flat_frames = dict(frames)
        self.calibration_metadata["flat_time"] = (
            datetime.datetime.now().isoformat()
        )
        self.calibration_metadata["flat_keys"] = list(frames.keys())
        self.update_calibration_status()
        self.apply_preview_light()
        self.status_label.setText("Flat reference가 저장되었습니다.")

    def start_led_calibration(self):
        if self.busy:
            return

        answer = QMessageBox.question(
            self,
            "LED calibration",
            "시료를 제거하고 빈 슬라이드와 고정 노출을 사용하십시오. 계속합니까?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return

        self.lock_camera_controls()

        sequence = []
        brightness = self.brightness_slider.value()

        for index in range(64):
            sequence.append({
                "name": "led_{:02d}".format(index),
                "pixels": self.led.single_led_pattern(
                    index,
                    brightness,
                    "white"
                )
            })

        self.start_sequence(
            sequence,
            self.on_led_calibration_complete,
            "LED 밝기 보정",
            average_frames=2,
            flush_frames=1,
            settle_ms=150
        )

    def on_led_calibration_complete(self, frames, purpose):
        responses = []

        for index in range(64):
            frame = frames["led_{:02d}".format(index)]
            gray = to_gray(frame)
            roi = self.image_label.roi()
            if roi is None:
                height, width = gray.shape
                roi = (
                    int(width * 0.25),
                    int(height * 0.25),
                    int(width * 0.50),
                    int(height * 0.50)
                )
            response = float(np.mean(crop_roi(gray, roi)))
            responses.append(max(response, 1.0))

        target = float(np.median(responses))
        coefficients = target / np.asarray(
            responses,
            dtype=np.float32
        )
        coefficients = np.clip(coefficients, 0.5, 2.0)

        self.led.set_coefficients(coefficients)
        self.calibration_metadata["led_time"] = (
            datetime.datetime.now().isoformat()
        )
        self.calibration_metadata["led_response"] = [
            float(value) for value in responses
        ]

        default_path = self.calibration_dir / "led_coefficients.json"
        self.led.save_coefficients(default_path)

        self.update_calibration_status()
        self.apply_preview_light()
        self.status_label.setText(
            "64 LED 밝기 보정이 완료되었습니다."
        )

    def save_calibration(self):
        path = QFileDialog.getSaveFileName(
            self,
            "보정 파일 저장",
            str(self.calibration_dir / "dpc_calibration.npz"),
            "NumPy archive (*.npz)"
        )
        if not path:
            return

        payload = {
            "metadata_json": np.asarray(
                json.dumps(
                    self.calibration_metadata,
                    ensure_ascii=False
                )
            ),
            "led_coefficients": self.led.coefficients,
        }

        if self.dark_frame is not None:
            payload["dark_frame"] = self.dark_frame

        for key, frame in self.flat_frames.items():
            payload["flat__" + key] = frame

        np.savez_compressed(str(path), **payload)
        self.status_label.setText("보정 파일 저장: " + str(path))

    def load_calibration(self):
        path = QFileDialog.getOpenFileName(
            self,
            "보정 파일 불러오기",
            str(self.calibration_dir),
            "NumPy archive (*.npz)"
        )
        if not path:
            return

        archive = np.load(str(path), allow_pickle=False)
        self.dark_frame = (
            archive["dark_frame"]
            if "dark_frame" in archive.files
            else None
        )

        self.flat_frames = {}
        for key in archive.files:
            if key.startswith("flat__"):
                self.flat_frames[key[len("flat__"):]] = archive[key]

        if "led_coefficients" in archive.files:
            self.led.set_coefficients(
                archive["led_coefficients"]
            )

        if "metadata_json" in archive.files:
            self.calibration_metadata = json.loads(
                str(archive["metadata_json"])
            )

        self.update_calibration_status()
        self.apply_preview_light()
        self.status_label.setText("보정 파일을 불러왔습니다.")

    def reset_calibration(self):
        self.dark_frame = None
        self.flat_frames = {}
        self.calibration_metadata = {}
        self.led.reset_coefficients()
        self.update_calibration_status()
        self.apply_preview_light()

    def update_calibration_status(self):
        dark_text = (
            "있음"
            if self.dark_frame is not None
            else "없음"
        )
        flat_text = "{}개 방향".format(
            len(self.flat_frames)
        )
        coefficient_range = (
            float(np.min(self.led.coefficients)),
            float(np.max(self.led.coefficients))
        )

        self.calibration_status.setHtml(
            "<b>Dark reference:</b> {}<br>"
            "<b>Flat reference:</b> {}<br>"
            "<b>LED coefficient range:</b> {:.3f} ~ {:.3f}<br>"
            "<b>Metadata:</b> {}".format(
                dark_text,
                flat_text,
                coefficient_range[0],
                coefficient_range[1],
                self.calibration_metadata
            )
        )

    # =========================================================
    # Auto optimization
    # =========================================================

    def start_auto_optimize(self):
        if self.busy or self.optimize_active:
            return

        self.optimize_active = True
        self.optimize_results = []
        self.optimize_index = 0

        candidates = []
        brightness_values = [80, 130, 190]
        radius_values = [1.6, 2.3, 3.0]
        source_values = [
            "half_annulus",
            "half_plane"
        ]

        current_exposure = self.cap.get(
            cv2.CAP_PROP_EXPOSURE
        )
        exposure_values = [None]

        if (
            self.optimize_exposure_check.isChecked() and
            current_exposure not in (-1, 0)
        ):
            exposure_values = [
                current_exposure - 1,
                current_exposure,
                current_exposure + 1
            ]

        for brightness in brightness_values:
            for radius in radius_values:
                for source in source_values:
                    for exposure in exposure_values:
                        candidates.append({
                            "brightness": brightness,
                            "radius": radius,
                            "source": source,
                            "exposure": exposure
                        })

        self.optimize_candidates = candidates
        self.optimize_status.setHtml(
            "총 {}개 후보를 평가합니다.".format(
                len(candidates)
            )
        )
        self.run_next_optimize_candidate()

    def run_next_optimize_candidate(self):
        if not self.optimize_active:
            return

        if self.optimize_index >= len(self.optimize_candidates):
            self.finish_auto_optimize()
            return

        candidate = self.optimize_candidates[
            self.optimize_index
        ]

        if candidate["exposure"] is not None:
            self.cap.set(
                cv2.CAP_PROP_EXPOSURE,
                candidate["exposure"]
            )

        sequence = self.build_dpc_sequence(
            direction_count=4,
            rgb=False,
            brightness=candidate["brightness"],
            radius=candidate["radius"],
            source_mode=candidate["source"]
        )

        self.start_sequence(
            sequence,
            self.on_optimize_candidate_complete,
            "자동 최적화 {}/{}".format(
                self.optimize_index + 1,
                len(self.optimize_candidates)
            ),
            average_frames=1,
            flush_frames=2,
            settle_ms=300
        )

    def on_optimize_candidate_complete(self, frames, purpose):
        candidate = dict(
            self.optimize_candidates[self.optimize_index]
        )

        prepared = {}
        for direction, frame in frames.items():
            prepared[direction] = to_gray(frame)

        aligned, shifts = register_frames(
            prepared,
            "phase"
        )
        gx, gy = compute_dpc_4(aligned)
        quality = dpc_quality(
            gx,
            gy,
            list(frames.values())[0],
            shifts,
            self.image_label.roi()
        )

        candidate["score"] = quality["score"]
        candidate["quality"] = quality
        self.optimize_results.append(candidate)

        self.optimize_status.setHtml(
            "후보 {}/{}<br>"
            "밝기 {} / 반지름 {:.1f} / 광원 {}<br>"
            "품질 점수 {:.1f}".format(
                self.optimize_index + 1,
                len(self.optimize_candidates),
                candidate["brightness"],
                candidate["radius"],
                candidate["source"],
                candidate["score"]
            )
        )

        self.optimize_index += 1
        QTimer.singleShot(
            50,
            self.run_next_optimize_candidate
        )

    def finish_auto_optimize(self):
        self.optimize_active = False

        if not self.optimize_results:
            return

        best = max(
            self.optimize_results,
            key=lambda item: item["score"]
        )

        self.brightness_slider.setValue(
            int(best["brightness"])
        )
        self.radius_spin.setValue(
            float(best["radius"])
        )
        self.source_combo.setCurrentIndex(
            0 if best["source"] == "half_annulus" else 1
        )

        if best["exposure"] is not None:
            self.cap.set(
                cv2.CAP_PROP_EXPOSURE,
                best["exposure"]
            )

        self.optimize_status.setHtml(
            "<b>최적 조건</b><br>"
            "밝기: {}<br>"
            "차광 반지름: {:.1f}<br>"
            "광원: {}<br>"
            "노출: {}<br>"
            "품질 점수: {:.1f}".format(
                best["brightness"],
                best["radius"],
                best["source"],
                best["exposure"],
                best["score"]
            )
        )
        self.apply_preview_light()
        self.status_label.setText("DPC 자동 최적화 완료")

    # =========================================================
    # Focus assist and external autofocus
    # =========================================================

    def start_autofocus(self):
        if self.busy or self.autofocus_active:
            return

        command = str(self.focus_command_edit.text()).strip()
        if "{delta}" not in command:
            QMessageBox.warning(
                self,
                "자동 초점 설정",
                "Z축 명령 템플릿에 {delta}가 포함되어야 합니다."
            )
            return

        range_steps = self.focus_range_spin.value()
        step_size = self.focus_step_spin.value()

        self.autofocus_positions = [
            position * step_size
            for position in range(
                -range_steps,
                range_steps + 1
            )
        ]
        self.autofocus_scores = []
        self.autofocus_index = 0
        self.autofocus_current_position = 0
        self.autofocus_active = True
        self.busy = True

        first_position = self.autofocus_positions[0]
        self.move_stage(first_position)
        self.autofocus_current_position = first_position

        QTimer.singleShot(
            self.focus_settle_spin.value(),
            self.capture_autofocus_point
        )

    def capture_autofocus_point(self):
        if not self.autofocus_active:
            return

        frames = []
        for _ in range(3):
            ok, frame = self.cap.read()
            if ok and frame is not None:
                frames.append(frame.astype(np.float32))

        if not frames:
            self.cancel_current_task()
            return

        frame = np.mean(frames, axis=0).astype(np.uint8)
        score = focus_score(
            frame,
            self.image_label.roi()
        )

        position = self.autofocus_positions[
            self.autofocus_index
        ]
        self.autofocus_scores.append(
            (position, score)
        )

        self.status_label.setText(
            "자동 초점 {}/{} | 위치 {} | 점수 {:.1f}".format(
                self.autofocus_index + 1,
                len(self.autofocus_positions),
                position,
                score
            )
        )
        self.display_image(
            self.apply_zoom(frame),
            "Autofocus"
        )

        self.autofocus_index += 1

        if self.autofocus_index >= len(
            self.autofocus_positions
        ):
            self.finish_autofocus()
            return

        next_position = self.autofocus_positions[
            self.autofocus_index
        ]
        delta = (
            next_position -
            self.autofocus_current_position
        )
        self.move_stage(delta)
        self.autofocus_current_position = next_position

        QTimer.singleShot(
            self.focus_settle_spin.value(),
            self.capture_autofocus_point
        )

    def finish_autofocus(self):
        best_position, best_score = max(
            self.autofocus_scores,
            key=lambda item: item[1]
        )

        delta = (
            best_position -
            self.autofocus_current_position
        )
        self.move_stage(delta)

        self.autofocus_current_position = best_position
        self.autofocus_active = False
        self.busy = False

        self.status_label.setText(
            "자동 초점 완료 | 최적 위치 {} | 점수 {:.1f}".format(
                best_position,
                best_score
            )
        )

    def move_stage(self, delta):
        command_template = str(
            self.focus_command_edit.text()
        ).strip()
        command = command_template.format(
            delta=int(delta)
        )
        try:
            subprocess.call(
                command,
                shell=True
            )
        except Exception as error:
            print("[Autofocus] stage command error:", repr(error))

    # =========================================================
    # Optics information
    # =========================================================

    def update_optics_info(self, value=None):
        if not hasattr(self, "led_pitch_spin"):
            return

        illumination_na = illumination_na_estimate(
            self.radius_spin.value(),
            self.led_pitch_spin.value(),
            self.led_distance_spin.value()
        )

        specimen_pixel_um = (
            self.camera_pixel_spin.value() /
            self.magnification_spin.value()
        )

        relation = (
            "조명 NA가 대물렌즈 NA보다 작습니다."
            if illumination_na < self.objective_na_spin.value()
            else "조명 NA가 대물렌즈 NA와 같거나 큽니다."
        )

        self.optics_info_label.setText(
            "추정 조명 NA: {:.3f} | 시료면 픽셀: {:.3f} um | {}".format(
                illumination_na,
                specimen_pixel_um,
                relation
            )
        )

    # =========================================================
    # ROI and analysis
    # =========================================================

    def on_roi_changed(self, roi):
        if roi is None:
            self.roi_status_label.setText("ROI: 전체 영상")
        else:
            self.roi_status_label.setText(
                "ROI: x={} y={} w={} h={}".format(
                    roi[0],
                    roi[1],
                    roi[2],
                    roi[3]
                )
            )

    def analysis_source_image(self):
        source = str(
            self.analysis_source_combo.currentText()
        )

        if source == "현재 표시 영상":
            return self.current_display
        if source == "Live":
            return self.current_frame
        return self.result_images.get(source)

    def run_classical_analysis(self):
        image = self.analysis_source_image()
        if image is None:
            QMessageBox.warning(
                self,
                "분석 오류",
                "분석할 영상이 없습니다."
            )
            return

        overlay, measurements = classical_segment(
            image,
            self.image_label.roi(),
            self.threshold_spin.value(),
            self.min_area_spin.value(),
            self.max_area_spin.value(),
            self.segment_invert_check.isChecked()
        )

        self.result_images["Analysis overlay"] = overlay
        self.result_combo.setCurrentIndex(
            self.result_combo.findText(
                "Analysis overlay"
            )
        )
        self.update_result_display()

        if measurements:
            areas = [item["area"] for item in measurements]
            circularities = [
                item["circularity"]
                for item in measurements
            ]
            html = (
                "<b>검출 개수:</b> {}<br>"
                "<b>평균 면적:</b> {:.1f} px²<br>"
                "<b>평균 원형도:</b> {:.3f}<br>"
                "<b>면적 범위:</b> {:.1f} ~ {:.1f}"
            ).format(
                len(measurements),
                float(np.mean(areas)),
                float(np.mean(circularities)),
                float(np.min(areas)),
                float(np.max(areas))
            )
        else:
            html = "조건에 맞는 윤곽이 검출되지 않았습니다."

        self.analysis_result_browser.setHtml(html)

    def load_onnx_model(self):
        path = QFileDialog.getOpenFileName(
            self,
            "ONNX 모델 불러오기",
            str(self.base_dir),
            "ONNX model (*.onnx)"
        )
        if not path:
            return

        try:
            self.onnx_segmenter.load(path)
            self.onnx_path_edit.setText(str(path))
            self.analysis_result_browser.setHtml(
                "ONNX 모델을 불러왔습니다.<br>" +
                str(path)
            )
        except Exception as error:
            QMessageBox.warning(
                self,
                "ONNX 오류",
                repr(error)
            )

    def run_onnx_analysis(self):
        image = self.analysis_source_image()
        if image is None:
            return

        if not self.onnx_segmenter.loaded:
            QMessageBox.warning(
                self,
                "ONNX 오류",
                "먼저 ONNX 모델을 불러오십시오."
            )
            return

        if len(image.shape) == 2:
            image = cv2.cvtColor(
                image,
                cv2.COLOR_GRAY2BGR
            )

        try:
            overlay, mask = self.onnx_segmenter.predict(
                image,
                self.onnx_width_spin.value(),
                self.onnx_height_spin.value(),
                self.onnx_threshold_spin.value()
            )
        except Exception as error:
            QMessageBox.warning(
                self,
                "ONNX 추론 오류",
                repr(error)
            )
            return

        self.result_images["Analysis overlay"] = overlay
        self.result_combo.setCurrentIndex(
            self.result_combo.findText(
                "Analysis overlay"
            )
        )
        self.update_result_display()

        self.analysis_result_browser.setHtml(
            "<b>ONNX 마스크 면적 비율:</b> {:.2%}".format(
                float(np.mean(mask > 0))
            )
        )

    # =========================================================
    # Timelapse
    # =========================================================

    def toggle_timelapse(self):
        if self.timelapse_active:
            self.timelapse_active = False
            self.btn_timelapse.setText("타임랩스 시작")
            self.timelapse_status_label.setText(
                "타임랩스: 중지"
            )
            return

        if self.busy:
            return

        self.timelapse_active = True
        self.timelapse_index = 0
        self.timelapse_target = (
            self.timelapse_count_spin.value()
        )
        self.btn_timelapse.setText("타임랩스 중지")
        self.start_next_timelapse_capture()

    def start_next_timelapse_capture(self):
        if not self.timelapse_active:
            return

        if (
            self.timelapse_target > 0 and
            self.timelapse_index >= self.timelapse_target
        ):
            self.timelapse_active = False
            self.btn_timelapse.setText("타임랩스 시작")
            self.timelapse_status_label.setText(
                "타임랩스: 완료"
            )
            return

        self.timelapse_status_label.setText(
            "타임랩스 촬영 {}".format(
                self.timelapse_index + 1
            )
        )
        self.start_dpc_capture("timelapse")

    def update_timelapse_after_capture(self):
        if not self.timelapse_active:
            return

        self.timelapse_status_label.setText(
            "완료 {}회 | 다음 촬영 대기".format(
                self.timelapse_index
            )
        )

        QTimer.singleShot(
            int(self.timelapse_interval_spin.value() * 1000),
            self.start_next_timelapse_capture
        )

    # =========================================================
    # Presets
    # =========================================================

    def presets_path(self):
        return self.base_dir / "presets.json"

    def load_presets(self):
        try:
            self.presets = json.loads(
                self.presets_path().read_text(
                    encoding="utf-8"
                )
            )
        except Exception:
            self.presets = {}

        self.refresh_preset_combo()

    def refresh_preset_combo(self):
        self.preset_combo.clear()
        for name in sorted(self.presets.keys()):
            self.preset_combo.addItem(name)

    def collect_settings(self):
        return {
            "brightness": self.brightness_slider.value(),
            "inner_radius": self.radius_spin.value(),
            "source_mode": self.source_mode(),
            "directions": self.direction_count(),
            "average_frames": self.average_spin.value(),
            "flush_frames": self.flush_spin.value(),
            "settle_ms": self.settle_spin.value(),
            "regularization": self.regularization_spin.value(),
            "wavelength_nm": self.wavelength_spin.value(),
            "phase_scale": self.phase_scale_spin.value(),
            "rgb": self.rgb_check.isChecked(),
            "registration": self.registration_check.isChecked()
        }

    def apply_settings(self, settings):
        self.brightness_slider.setValue(
            int(settings.get("brightness", 120))
        )
        self.radius_spin.setValue(
            float(settings.get("inner_radius", 2.2))
        )
        self.source_combo.setCurrentIndex(
            0 if settings.get(
                "source_mode",
                "half_annulus"
            ) == "half_annulus" else 1
        )
        self.direction_combo.setCurrentIndex(
            0 if int(settings.get("directions", 4)) == 4 else 1
        )
        self.average_spin.setValue(
            int(settings.get("average_frames", 4))
        )
        self.flush_spin.setValue(
            int(settings.get("flush_frames", 6))
        )
        self.settle_spin.setValue(
            int(settings.get("settle_ms", 700))
        )
        self.regularization_spin.setValue(
            float(settings.get("regularization", 0.002))
        )
        self.wavelength_spin.setValue(
            float(settings.get("wavelength_nm", 550.0))
        )
        self.phase_scale_spin.setValue(
            float(settings.get("phase_scale", 1.0))
        )
        self.rgb_check.setChecked(
            bool(settings.get("rgb", False))
        )
        self.registration_check.setChecked(
            bool(settings.get("registration", True))
        )
        self.apply_preview_light()

    def apply_selected_preset(self):
        name = str(self.preset_combo.currentText())
        if name in self.presets:
            self.apply_settings(self.presets[name])
            self.status_label.setText(
                "프리셋 적용: " + name
            )

    def save_current_preset(self):
        name = str(
            self.preset_name_edit.text()
        ).strip()

        if not name:
            name, ok = QInputDialog.getText(
                self,
                "프리셋 저장",
                "프리셋 이름:"
            )
            if not ok:
                return
            name = str(name).strip()

        if not name:
            return

        self.presets[name] = self.collect_settings()
        self.presets_path().write_text(
            json.dumps(
                self.presets,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )
        self.refresh_preset_combo()
        self.preset_combo.setCurrentIndex(
            self.preset_combo.findText(name)
        )
        self.status_label.setText(
            "프리셋 저장: " + name
        )

    def delete_selected_preset(self):
        name = str(self.preset_combo.currentText())
        if name not in self.presets:
            return

        del self.presets[name]
        self.presets_path().write_text(
            json.dumps(
                self.presets,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )
        self.refresh_preset_combo()

    # =========================================================
    # Save
    # =========================================================

    def save_current_image(self):
        if self.current_display is None:
            return

        stamp = datetime.datetime.now().strftime(
            "%Y%m%d_%H%M%S_%f"
        )[:-3]

        safe_name = (
            self.current_display_name
            .lower()
            .replace(" ", "_")
            .replace("-", "_")
        )

        path = self.output_dir / (
            stamp + "_" + safe_name + ".png"
        )

        cv2.imwrite(
            str(path),
            self.current_display
        )
        self.status_label.setText(
            "저장: " + str(path)
        )

    def save_result_bundle(self, prefix=None):
        stamp = datetime.datetime.now().strftime(
            "%Y%m%d_%H%M%S_%f"
        )[:-3]

        if prefix:
            stamp = str(prefix) + "_" + stamp

        for name, image in self.result_images.items():
            if image is None:
                continue
            safe_name = (
                name.lower()
                .replace(" ", "_")
                .replace("-", "_")
            )
            cv2.imwrite(
                str(
                    self.output_dir /
                    (stamp + "_" + safe_name + ".png")
                ),
                self.ensure_u8(image)
            )

        if self.save_raw_check.isChecked():
            for name, frame in self.last_raw_frames.items():
                cv2.imwrite(
                    str(
                        self.output_dir /
                        (stamp + "_raw_" + name + ".png")
                    ),
                    frame
                )

        if (
            self.save_float_check.isChecked() and
            self.result_float
        ):
            np.savez_compressed(
                str(
                    self.output_dir /
                    (stamp + "_dpc_float.npz")
                ),
                **self.result_float
            )

        metadata = {
            "timestamp": stamp,
            "settings": self.collect_settings(),
            "quality": self.last_quality,
            "registration": self.last_registration,
            "roi": self.image_label.roi(),
            "calibration_metadata": self.calibration_metadata
        }

        (
            self.output_dir /
            (stamp + "_metadata.json")
        ).write_text(
            json.dumps(
                metadata,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )

        self.status_label.setText(
            "결과 묶음 저장 완료: " + stamp
        )

    # =========================================================
    # Zoom and help
    # =========================================================

    def zoom_in(self):
        self.zoom = min(3.0, self.zoom + 0.2)
        self.update_result_display()

    def zoom_out(self):
        self.zoom = max(1.0, self.zoom - 0.2)
        self.update_result_display()

    def update_help_topic(self, value=None):
        topic = str(
            self.help_topic_combo.currentText()
        )
        self.help_browser.setHtml(
            HELP_TOPICS.get(topic, "")
        )

    # =========================================================
    # Shutdown
    # =========================================================

    def closeEvent(self, event):
        self.busy = False
        self.live_dpc_active = False
        self.timelapse_active = False
        self.autofocus_active = False
        self.optimize_active = False

        if hasattr(self, "live_timer"):
            self.live_timer.stop()

        if self.cap is not None and self.cap.isOpened():
            self.cap.release()

        self.led.clear()
        print("[System] closed")
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = AdvancedDPCGUI()
    window.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
