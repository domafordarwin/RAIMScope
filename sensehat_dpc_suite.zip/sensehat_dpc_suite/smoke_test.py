# -*- coding: utf-8 -*-

import numpy as np

from led_controller import LEDController
from dpc_engine import (
    compute_dpc_4,
    compute_dpc_8,
    integrate_gradients_fft
)


def main():
    controller = LEDController()

    pattern = controller.directional_pattern(
        180,
        brightness=100,
        inner_radius=2.2,
        source_mode="half_annulus"
    )
    assert len(pattern) == 64
    assert any(pixel != (0, 0, 0) for pixel in pattern)

    height = 120
    width = 160
    x = np.linspace(0.0, 1.0, width, dtype=np.float32)
    y = np.linspace(0.0, 1.0, height, dtype=np.float32)
    xx, yy = np.meshgrid(x, y)

    base = 1.0 + 0.2 * np.sin(xx * 10.0)
    gx_true = 0.05 * np.cos(xx * 10.0)
    gy_true = 0.04 * np.sin(yy * 8.0)

    frames4 = {
        "right": base * (1.0 + gx_true),
        "left": base * (1.0 - gx_true),
        "bottom": base * (1.0 + gy_true),
        "top": base * (1.0 - gy_true),
    }

    gx, gy = compute_dpc_4(frames4)
    assert gx.shape == (height, width)
    assert gy.shape == (height, width)

    frames8 = {
        "right": frames4["right"],
        "left": frames4["left"],
        "bottom": frames4["bottom"],
        "top": frames4["top"],
        "bottom_right": base * (1.0 + (gx_true + gy_true) / 1.414),
        "top_left": base * (1.0 - (gx_true + gy_true) / 1.414),
        "bottom_left": base * (1.0 + (-gx_true + gy_true) / 1.414),
        "top_right": base * (1.0 - (-gx_true + gy_true) / 1.414),
    }

    gx8, gy8 = compute_dpc_8(frames8)
    phase = integrate_gradients_fft(gx8, gy8)

    assert gx8.shape == (height, width)
    assert gy8.shape == (height, width)
    assert phase.shape == (height, width)
    assert np.isfinite(phase).all()

    print("Smoke test passed")


if __name__ == "__main__":
    main()
