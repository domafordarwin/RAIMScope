# Sense HAT Advanced DPC Microscope Suite

Raspberry Pi 4, Sense HAT 8x8 LED, USB microscope camera를 이용한 교육·실험용 DPC 현미경 GUI입니다.

## 1. 포함 기능

### 조명과 촬영
- 명시야, 암시야, 방향별 DPC 조명 미리보기
- 4방향 DPC
- 8방향 DPC
- RGB-DPC
- 실시간 반복 DPC
- 프레임 평균, 버퍼 제거, 조명 안정 시간 설정
- 카메라 자동 노출 및 노출/화이트밸런스 고정

### 영상 신뢰도
- Phase correlation 또는 ECC 영상 정렬
- Dark reference 보정
- 방향별 Flat reference 보정
- 64개 LED 개별 밝기 보정
- 과노출, 저노출, 초점, 이동량, SNR 품질 진단
- 마우스 드래그 ROI

### 최적화와 광학
- LED 밝기·중앙 차광 반지름·광원 형태 자동 최적화
- 실시간 초점 점수
- 외부 Z축 명령 기반 자동 초점
- 조명 NA와 시료면 픽셀 크기 추정
- Phase-like 복원
- 사용자 phase scale 기반 OPD estimate

### 분석과 기록
- 임계값·윤곽선 기반 세포/입자 개수, 면적, 둘레, 원형도
- 선택적 ONNX 분할 모델
- 타임랩스 DPC
- 시료별 프리셋
- PNG, 원본 방향 영상, NPZ 실수 배열, JSON 메타데이터 저장
- GUI 내부 기능 설명 탭

## 2. 설치

Raspberry Pi OS에서 다음 패키지가 필요합니다.

```bash
sudo apt update
sudo apt install python3-opencv python3-numpy python3-pyqt4 sense-hat
```

배포판에 `python3-pyqt4`가 없다면 현재 사용 중인 기존 PyQt4 환경을 유지하십시오.

## 3. 파일 복사

Windows PowerShell에서:

```powershell
scp .\sensehat_dpc_suite.zip pi@라즈베리파이_IP:/home/pi/project/2026_LED/
```

Raspberry Pi에서:

```bash
cd /home/pi/project/2026_LED
unzip sensehat_dpc_suite.zip
cd sensehat_dpc_suite
```

## 4. 문법 검사와 실행

```bash
python3 -m py_compile main.py
python3 -m py_compile led_controller.py
python3 -m py_compile dpc_engine.py
python3 -m py_compile analysis_engine.py
/bin/python3 main.py
```

또는:

```bash
chmod +x run.sh
./run.sh
```

## 5. 권장 첫 실행 순서

1. `조명/실시간` 탭에서 Bright field를 선택합니다.
2. 시료 위치와 초점을 맞춥니다.
3. 빈 슬라이드로 Dark reference와 Flat reference를 촬영합니다.
4. DPC 촬영 탭에서 영상 정렬과 Dark/Flat 보정을 켭니다.
5. 4 directions, 평균 4장, flush 6장, settle 700 ms로 시작합니다.
6. DPC 촬영을 실행합니다.
7. 품질 진단의 포화·이동량·SNR을 확인합니다.
8. 필요하면 자동 최적화를 실행합니다.
9. 결과가 안정되면 8 directions 또는 RGB-DPC를 시험합니다.

## 6. 외부 Z축 자동 초점

GUI의 `Z축 명령 템플릿`에는 `{delta}`가 포함된 명령을 입력해야 합니다.

예:

```text
python3 /home/pi/project/stage_move.py {delta}
```

프로그램은 `{delta}`에 양수 또는 음수 이동량을 넣어 명령을 실행합니다. 실제 스테퍼 모터·피에조 제어 스크립트는 사용 중인 하드웨어에 맞게 별도로 준비해야 합니다.

## 7. ONNX 분석

GUI는 다음 형태의 출력을 우선 지원합니다.

- `[1, 1, H, W]`: 단일 분할 마스크
- `[1, C, H, W]`: 두 번째 채널을 대상 마스크로 사용
- `[1, H, W]`
- `[H, W]`

모델마다 전처리와 출력 구조가 다르므로 실제 모델에 맞춰 `analysis_engine.py`의 `ONNXSegmenter`를 수정해야 할 수 있습니다.

## 8. 중요한 한계

`Phase-like`는 DPC 경사를 FFT로 적분한 정성적 결과입니다. `OPD estimate`는 사용자 phase scale을 적용한 추정값입니다. 실제 위상 지연, 굴절률, 세포 두께를 정량 측정하려면 LED 위치, 파장, 조명 NA, 대물렌즈 전달함수, 카메라 픽셀 크기에 대한 별도 교정이 필요합니다.

Sense HAT LED는 정밀 단색광원이나 고밀도 LED 어레이가 아니므로 이 시스템은 교육, 비교 실험, 프로토타이핑에 가장 적합합니다.
