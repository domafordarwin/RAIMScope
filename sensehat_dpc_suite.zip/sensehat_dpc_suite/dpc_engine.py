# -*- coding: utf-8 -*-

import math

import cv2
import numpy as np


DIRECTION_ANGLES = {
    "right": 0.0,
    "bottom_right": 45.0,
    "bottom": 90.0,
    "bottom_left": 135.0,
    "left": 180.0,
    "top_left": 225.0,
    "top": 270.0,
    "top_right": 315.0,
}


def focus_score(frame, roi=None):
    gray = to_gray(frame)
    gray = crop_roi(gray, roi)
    if gray.size == 0:
        return 0.0
    laplacian = cv2.Laplacian(gray, cv2.CV_32F)
    return float(np.var(laplacian))


def crop_roi(image, roi):
    if roi is None:
        return image
    x, y, width, height = [int(v) for v in roi]
    x = max(0, x)
    y = max(0, y)
    width = max(1, width)
    height = max(1, height)
    return image[y:y + height, x:x + width]


def to_gray(frame, color_name="white"):
    if frame is None:
        return None

    if len(frame.shape) == 2:
        return frame.astype(np.float32)

    color_name = str(color_name).lower()
    if color_name == "red":
        return frame[:, :, 2].astype(np.float32)
    if color_name == "green":
        return frame[:, :, 1].astype(np.float32)
    if color_name == "blue":
        return frame[:, :, 0].astype(np.float32)

    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)


def correct_frame(frame, dark_frame=None, flat_frame=None):
    image = frame.astype(np.float32)

    if dark_frame is not None:
        image = image - dark_frame.astype(np.float32)

    image = np.maximum(image, 0.0)

    if flat_frame is not None:
        flat = flat_frame.astype(np.float32)
        if dark_frame is not None:
            flat = flat - dark_frame.astype(np.float32)

        flat = np.maximum(flat, 1.0)
        scale = float(np.median(flat))
        image = image / flat * scale

    return np.clip(image, 0.0, 65535.0)


def _register_phase(reference_gray, moving_gray):
    reference = reference_gray.astype(np.float32)
    moving = moving_gray.astype(np.float32)

    height, width = reference.shape
    window = cv2.createHanningWindow((width, height), cv2.CV_32F)
    shift, response = cv2.phaseCorrelate(
        reference * window,
        moving * window
    )

    dx, dy = shift
    transform = np.float32([
        [1.0, 0.0, -dx],
        [0.0, 1.0, -dy]
    ])

    aligned = cv2.warpAffine(
        moving,
        transform,
        (width, height),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT
    )

    return aligned, (float(dx), float(dy)), float(response)


def _register_ecc(reference_gray, moving_gray):
    reference = reference_gray.astype(np.float32)
    moving = moving_gray.astype(np.float32)

    reference = cv2.normalize(
        reference,
        None,
        0.0,
        1.0,
        cv2.NORM_MINMAX
    )
    moving = cv2.normalize(
        moving,
        None,
        0.0,
        1.0,
        cv2.NORM_MINMAX
    )

    warp = np.eye(2, 3, dtype=np.float32)
    criteria = (
        cv2.TERM_CRITERIA_EPS |
        cv2.TERM_CRITERIA_COUNT,
        60,
        1e-6
    )

    try:
        correlation, warp = cv2.findTransformECC(
            reference,
            moving,
            warp,
            cv2.MOTION_TRANSLATION,
            criteria
        )

        aligned = cv2.warpAffine(
            moving,
            warp,
            (reference.shape[1], reference.shape[0]),
            flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
            borderMode=cv2.BORDER_REFLECT
        )

        return (
            aligned,
            (float(warp[0, 2]), float(warp[1, 2])),
            float(correlation)
        )
    except Exception:
        return _register_phase(reference_gray, moving_gray)


def register_frames(frames, method="phase"):
    if not frames:
        return {}, {}

    names = list(frames.keys())
    reference_name = names[0]
    reference = to_gray(frames[reference_name])

    aligned = {reference_name: reference.copy()}
    shifts = {
        reference_name: {
            "dx": 0.0,
            "dy": 0.0,
            "response": 1.0
        }
    }

    for name in names[1:]:
        moving = to_gray(frames[name])

        if method == "ecc":
            registered, shift, response = _register_ecc(
                reference,
                moving
            )
        else:
            registered, shift, response = _register_phase(
                reference,
                moving
            )

        aligned[name] = registered
        shifts[name] = {
            "dx": shift[0],
            "dy": shift[1],
            "response": response
        }

    return aligned, shifts


def compute_dpc_4(frames, invert_x=False, invert_y=False):
    epsilon = 1e-6
    right = frames["right"].astype(np.float32)
    left = frames["left"].astype(np.float32)
    bottom = frames["bottom"].astype(np.float32)
    top = frames["top"].astype(np.float32)

    gx = (right - left) / (right + left + epsilon)
    gy = (bottom - top) / (bottom + top + epsilon)

    if invert_x:
        gx = -gx
    if invert_y:
        gy = -gy

    return gx.astype(np.float32), gy.astype(np.float32)


def compute_dpc_8(frames, invert_x=False, invert_y=False):
    """
    Estimate gx and gy by least squares using four opposite direction pairs.
    """
    epsilon = 1e-6
    pairs = [
        ("right", "left", 0.0),
        ("bottom_right", "top_left", 45.0),
        ("bottom", "top", 90.0),
        ("bottom_left", "top_right", 135.0),
    ]

    observations = []
    matrix_rows = []

    for positive_name, negative_name, angle_degrees in pairs:
        positive = frames[positive_name].astype(np.float32)
        negative = frames[negative_name].astype(np.float32)
        difference = (
            (positive - negative) /
            (positive + negative + epsilon)
        )
        observations.append(difference)

        theta = math.radians(angle_degrees)
        matrix_rows.append([
            math.cos(theta),
            math.sin(theta)
        ])

    matrix = np.asarray(matrix_rows, dtype=np.float32)
    pseudo_inverse = np.linalg.pinv(matrix)
    stacked = np.stack(observations, axis=0)

    gx = (
        pseudo_inverse[0, :, None, None] * stacked
    ).sum(axis=0)
    gy = (
        pseudo_inverse[1, :, None, None] * stacked
    ).sum(axis=0)

    if invert_x:
        gx = -gx
    if invert_y:
        gy = -gy

    return gx.astype(np.float32), gy.astype(np.float32)


def integrate_gradients_fft(gx, gy, regularization=0.002):
    height, width = gx.shape

    gx = gx.astype(np.float32) - float(np.mean(gx))
    gy = gy.astype(np.float32) - float(np.mean(gy))

    window = np.outer(
        np.hanning(height),
        np.hanning(width)
    ).astype(np.float32)

    gx_fft = np.fft.fft2(gx * window)
    gy_fft = np.fft.fft2(gy * window)

    ky = 2.0 * np.pi * np.fft.fftfreq(height)
    kx = 2.0 * np.pi * np.fft.fftfreq(width)
    kx_grid, ky_grid = np.meshgrid(kx, ky)

    denominator = (
        kx_grid ** 2 +
        ky_grid ** 2 +
        max(float(regularization), 1e-9)
    )

    phase_fft = (
        -1j * kx_grid * gx_fft -
        1j * ky_grid * gy_fft
    ) / denominator

    phase_fft[0, 0] = 0.0
    phase = np.real(np.fft.ifft2(phase_fft))
    phase = phase - float(np.mean(phase))
    return phase.astype(np.float32)


def signed_to_u8(array, percentile=99.0):
    finite = array[np.isfinite(array)]
    if finite.size == 0:
        return np.zeros(array.shape, dtype=np.uint8)

    scale = float(np.percentile(np.abs(finite), percentile))
    if scale < 1e-8:
        scale = 1.0

    normalized = np.clip(array / scale, -1.0, 1.0)
    return np.clip(
        normalized * 127.0 + 128.0,
        0,
        255
    ).astype(np.uint8)


def positive_to_u8(array, percentile=99.0):
    finite = array[np.isfinite(array)]
    if finite.size == 0:
        return np.zeros(array.shape, dtype=np.uint8)

    scale = float(np.percentile(finite, percentile))
    if scale < 1e-8:
        scale = 1.0

    normalized = np.clip(array / scale, 0.0, 1.0)
    return (normalized * 255.0).astype(np.uint8)


def dpc_color(gx, gy):
    angle = np.arctan2(gy, gx)
    magnitude = np.sqrt(gx ** 2 + gy ** 2)

    hue = (
        (angle + np.pi) /
        (2.0 * np.pi) *
        179.0
    ).astype(np.uint8)

    value = positive_to_u8(magnitude)
    saturation = np.full(
        magnitude.shape,
        255,
        dtype=np.uint8
    )

    hsv = cv2.merge([hue, saturation, value])
    return cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)


def exposure_metrics(frame, roi=None):
    gray = to_gray(frame)
    gray = crop_roi(gray, roi)

    if gray.size == 0:
        return {
            "mean": 0.0,
            "saturation": 0.0,
            "underexposure": 1.0,
            "focus": 0.0
        }

    return {
        "mean": float(np.mean(gray)),
        "saturation": float(np.mean(gray >= 250.0)),
        "underexposure": float(np.mean(gray <= 5.0)),
        "focus": focus_score(gray)
    }


def dpc_quality(gx, gy, source_frame=None, shifts=None, roi=None):
    gx_roi = crop_roi(gx, roi)
    gy_roi = crop_roi(gy, roi)
    magnitude = np.sqrt(gx_roi ** 2 + gy_roi ** 2)

    signal = float(np.percentile(magnitude, 95.0))
    noise = float(np.std(magnitude - cv2.GaussianBlur(
        magnitude,
        (0, 0),
        2.0
    )))
    snr = signal / (noise + 1e-6)

    quality = {
        "mean_abs_x": float(np.mean(np.abs(gx_roi))),
        "mean_abs_y": float(np.mean(np.abs(gy_roi))),
        "p95_magnitude": signal,
        "noise": noise,
        "snr": snr,
        "max_motion": 0.0,
    }

    if source_frame is not None:
        quality.update(exposure_metrics(source_frame, roi))

    if shifts:
        motions = []
        for item in shifts.values():
            motions.append(math.sqrt(
                item["dx"] ** 2 +
                item["dy"] ** 2
            ))
        quality["max_motion"] = max(motions) if motions else 0.0

    quality["score"] = (
        25.0 * min(snr / 8.0, 1.0) +
        25.0 * min(signal / 0.15, 1.0) +
        20.0 * min(quality.get("focus", 0.0) / 300.0, 1.0) +
        15.0 * (1.0 - min(quality.get("saturation", 0.0) / 0.05, 1.0)) +
        15.0 * (1.0 - min(quality.get("max_motion", 0.0) / 3.0, 1.0))
    )

    return quality


def illumination_na_estimate(
    inner_radius_pixels,
    led_pitch_mm,
    led_distance_mm
):
    radial_mm = float(inner_radius_pixels) * float(led_pitch_mm)
    angle = math.atan2(radial_mm, max(float(led_distance_mm), 1e-9))
    return math.sin(angle)


def opd_from_phase_like(
    phase_like,
    wavelength_nm=550.0,
    phase_scale=1.0
):
    phase_radians = phase_like.astype(np.float32) * float(phase_scale)
    opd_nm = (
        phase_radians *
        float(wavelength_nm) /
        (2.0 * np.pi)
    )
    return opd_nm.astype(np.float32)
