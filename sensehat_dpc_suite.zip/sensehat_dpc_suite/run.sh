#!/bin/bash
set -e
cd "$(dirname "$0")"
exec /bin/python3 main.py
