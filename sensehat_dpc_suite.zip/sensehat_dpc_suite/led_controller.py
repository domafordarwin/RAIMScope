# -*- coding: utf-8 -*-

import json
import math
from pathlib import Path

import numpy as np

try:
    from sense_hat import SenseHat
except Exception:
    SenseHat = None


class LEDController(object):
    """Sense HAT LED pattern generator and calibration wrapper."""

    COLOR_MAP = {
        "white": (1.0, 1.0, 1.0),
        "red": (1.0, 0.0, 0.0),
        "green": (0.0, 1.0, 0.0),
        "blue": (0.0, 0.0, 1.0),
    }

    def __init__(self):
        self.sense = None
        self.available = False
        self.coefficients = np.ones(64, dtype=np.float32)
        self.last_pixels = [(0, 0, 0)] * 64
        self.last_name = "off"

        if SenseHat is None:
            return

        try:
            self.sense = SenseHat()
            self.sense.gamma_reset()
            self.sense.low_light = False
            self.sense.clear()
            self.available = True
        except Exception:
            self.sense = None
            self.available = False

    @staticmethod
    def _clip(value):
        return int(max(0, min(255, round(value))))

    def set_coefficients(self, values):
        values = np.asarray(values, dtype=np.float32).reshape(-1)
        if values.size != 64:
            raise ValueError("LED calibration must contain 64 values")
        self.coefficients = np.clip(values, 0.25, 4.0)

    def reset_coefficients(self):
        self.coefficients = np.ones(64, dtype=np.float32)

    def save_coefficients(self, path):
        path = Path(path)
        payload = {
            "version": 1,
            "coefficients": [float(v) for v in self.coefficients],
        }
        path.write_text(
            json.dumps(payload, indent=2),
            encoding="utf-8"
        )

    def load_coefficients(self, path):
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        self.set_coefficients(payload["coefficients"])

    def _apply_coefficients(self, pixels):
        corrected = []
        for index, pixel in enumerate(pixels):
            coefficient = float(self.coefficients[index])
            corrected.append((
                self._clip(pixel[0] * coefficient),
                self._clip(pixel[1] * coefficient),
                self._clip(pixel[2] * coefficient),
            ))
        return corrected

    def apply(self, pixels, name="custom"):
        corrected = self._apply_coefficients(pixels)
        self.last_pixels = list(corrected)
        self.last_name = str(name)

        if not self.available:
            return False

        self.sense.set_pixels(corrected)
        return True

    def clear(self):
        self.last_pixels = [(0, 0, 0)] * 64
        self.last_name = "off"
        if self.available:
            self.sense.clear()

    @staticmethod
    def _base_color(brightness, color_name):
        brightness = int(max(0, min(255, brightness)))
        multiplier = LEDController.COLOR_MAP.get(
            str(color_name).lower(),
            LEDController.COLOR_MAP["white"]
        )
        return (
            int(brightness * multiplier[0]),
            int(brightness * multiplier[1]),
            int(brightness * multiplier[2]),
        )

    def off_pattern(self):
        return [(0, 0, 0)] * 64

    def brightfield_pattern(self, brightness=120, color_name="white"):
        color = self._base_color(brightness, color_name)
        return [color] * 64

    def annulus_pattern(
        self,
        brightness=120,
        inner_radius=2.2,
        outer_radius=5.1,
        color_name="white"
    ):
        color = self._base_color(brightness, color_name)
        black = (0, 0, 0)
        pixels = []

        for y in range(8):
            for x in range(8):
                radius = math.sqrt((x - 3.5) ** 2 + (y - 3.5) ** 2)
                if inner_radius <= radius <= outer_radius:
                    pixels.append(color)
                else:
                    pixels.append(black)

        return pixels

    def directional_pattern(
        self,
        angle_degrees,
        brightness=120,
        inner_radius=2.2,
        outer_radius=5.1,
        source_mode="half_annulus",
        color_name="white"
    ):
        """
        angle_degrees indicates the center direction of the illuminated half.
        0=right, 90=bottom, 180=left, 270=top in image coordinates.
        """
        color = self._base_color(brightness, color_name)
        black = (0, 0, 0)
        angle = math.radians(float(angle_degrees))
        direction_x = math.cos(angle)
        direction_y = math.sin(angle)
        pixels = []

        for y in range(8):
            for x in range(8):
                dx = x - 3.5
                dy = y - 3.5
                radius = math.sqrt(dx * dx + dy * dy)
                side_ok = (dx * direction_x + dy * direction_y) >= 0.0

                if source_mode == "half_plane":
                    radial_ok = True
                else:
                    radial_ok = inner_radius <= radius <= outer_radius

                pixels.append(color if side_ok and radial_ok else black)

        return pixels

    def single_led_pattern(
        self,
        led_index,
        brightness=120,
        color_name="white"
    ):
        pixels = [(0, 0, 0)] * 64
        if 0 <= int(led_index) < 64:
            pixels[int(led_index)] = self._base_color(
                brightness,
                color_name
            )
        return pixels

    def pattern_for_name(
        self,
        name,
        brightness=120,
        inner_radius=2.2,
        source_mode="half_annulus",
        color_name="white"
    ):
        mapping = {
            "right": 0.0,
            "bottom_right": 45.0,
            "bottom": 90.0,
            "bottom_left": 135.0,
            "left": 180.0,
            "top_left": 225.0,
            "top": 270.0,
            "top_right": 315.0,
        }

        if name == "off":
            return self.off_pattern()
        if name == "brightfield":
            return self.brightfield_pattern(brightness, color_name)
        if name == "darkfield":
            return self.annulus_pattern(
                brightness,
                inner_radius,
                5.1,
                color_name
            )
        if name in mapping:
            return self.directional_pattern(
                mapping[name],
                brightness,
                inner_radius,
                5.1,
                source_mode,
                color_name
            )
        raise ValueError("Unknown LED pattern: " + str(name))
