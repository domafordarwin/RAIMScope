# -*- coding: utf-8 -*-

from pathlib import Path

import cv2
import numpy as np


def classical_segment(
    frame,
    roi=None,
    threshold=0,
    min_area=20,
    max_area=100000,
    invert=False
):
    if frame is None:
        return None, []

    if len(frame.shape) == 2:
        gray = frame.copy()
        base = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
    else:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        base = frame.copy()

    mask_limit = np.zeros(gray.shape, dtype=np.uint8)
    if roi is None:
        mask_limit[:, :] = 255
    else:
        x, y, width, height = [int(v) for v in roi]
        mask_limit[
            max(0, y):max(0, y) + max(1, height),
            max(0, x):max(0, x) + max(1, width)
        ] = 255

    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    if int(threshold) <= 0:
        threshold_type = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
        _, binary = cv2.threshold(
            blurred,
            0,
            255,
            threshold_type | cv2.THRESH_OTSU
        )
    else:
        threshold_type = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
        _, binary = cv2.threshold(
            blurred,
            int(threshold),
            255,
            threshold_type
        )

    binary = cv2.bitwise_and(binary, mask_limit)

    kernel = np.ones((3, 3), dtype=np.uint8)
    binary = cv2.morphologyEx(
        binary,
        cv2.MORPH_OPEN,
        kernel,
        iterations=1
    )
    binary = cv2.morphologyEx(
        binary,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=2
    )

    contours_result = cv2.findContours(
        binary,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )
    contours = contours_result[-2]

    measurements = []
    accepted = []

    for contour in contours:
        area = float(cv2.contourArea(contour))
        if area < float(min_area) or area > float(max_area):
            continue

        perimeter = float(cv2.arcLength(contour, True))
        circularity = (
            4.0 * np.pi * area /
            (perimeter * perimeter + 1e-9)
        )
        x, y, width, height = cv2.boundingRect(contour)

        accepted.append(contour)
        measurements.append({
            "area": area,
            "perimeter": perimeter,
            "circularity": float(circularity),
            "x": int(x),
            "y": int(y),
            "width": int(width),
            "height": int(height),
        })

    overlay = base.copy()
    cv2.drawContours(
        overlay,
        accepted,
        -1,
        (0, 255, 0),
        1
    )

    for index, item in enumerate(measurements):
        cv2.putText(
            overlay,
            str(index + 1),
            (item["x"], max(0, item["y"] - 3)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.35,
            (0, 255, 255),
            1,
            cv2.LINE_AA
        )

    return overlay, measurements


class ONNXSegmenter(object):
    """Generic single-mask ONNX segmentation adapter."""

    def __init__(self):
        self.net = None
        self.path = None

    @property
    def loaded(self):
        return self.net is not None

    def load(self, path):
        path = str(Path(path))
        self.net = cv2.dnn.readNetFromONNX(path)
        self.path = path

    def predict(
        self,
        frame,
        input_width=256,
        input_height=256,
        threshold=0.5
    ):
        if self.net is None:
            raise RuntimeError("No ONNX model is loaded")

        original_height, original_width = frame.shape[:2]

        blob = cv2.dnn.blobFromImage(
            frame,
            scalefactor=1.0 / 255.0,
            size=(int(input_width), int(input_height)),
            mean=(0.0, 0.0, 0.0),
            swapRB=True,
            crop=False
        )

        self.net.setInput(blob)
        output = self.net.forward()
        output = np.asarray(output)

        if output.ndim == 4:
            if output.shape[1] == 1:
                mask = output[0, 0]
            else:
                mask = output[0, 1]
        elif output.ndim == 3:
            mask = output[0]
        elif output.ndim == 2:
            mask = output
        else:
            raise RuntimeError(
                "Unsupported ONNX output shape: " +
                str(output.shape)
            )

        mask = cv2.resize(
            mask.astype(np.float32),
            (original_width, original_height),
            interpolation=cv2.INTER_LINEAR
        )

        minimum = float(np.min(mask))
        maximum = float(np.max(mask))
        if maximum - minimum > 1e-8:
            mask = (mask - minimum) / (maximum - minimum)

        binary = (mask >= float(threshold)).astype(np.uint8) * 255

        contours_result = cv2.findContours(
            binary,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )
        contours = contours_result[-2]

        overlay = frame.copy()
        cv2.drawContours(
            overlay,
            contours,
            -1,
            (255, 0, 255),
            1
        )

        return overlay, binary
