# 구현 계획과 구조

## 1단계: 장치 계층

`led_controller.py`

- Sense HAT 초기화
- 명시야·암시야·4/8방향 DPC 패턴
- RGB 조명
- 64개 LED 보정 계수 적용
- 보정 계수 저장과 불러오기

## 2단계: 영상 처리 계층

`dpc_engine.py`

- Dark/Flat 보정
- Phase correlation 및 ECC 정렬
- 4방향 DPC
- 8방향 최소제곱 DPC
- FFT 위상 유사 복원
- OPD 추정
- 노출·초점·이동·SNR 품질 평가
- 광학 파라미터 추정

## 3단계: 분석 계층

`analysis_engine.py`

- Otsu 또는 수동 임계값 분할
- 윤곽선 기반 개수·면적·둘레·원형도
- 일반적인 단일 마스크 ONNX 분할 어댑터

## 4단계: 사용자 인터페이스

`main.py`

- 조명/실시간
- DPC 촬영
- 보정
- 자동 최적화/초점
- 분석/AI
- 타임랩스/프리셋
- 기능 설명

긴 작업은 QTimer 기반 순차 상태 기계로 실행하여 GUI가 완전히 멈추는 것을 줄였습니다.

## 5단계: 검증

- 모든 Python 파일 `py_compile` 통과
- `smoke_test.py`로 하드웨어 없이 패턴과 DPC 수학 검사
- 실제 Raspberry Pi에서는 카메라 노출 제어와 Sense HAT 방향을 별도로 검증
